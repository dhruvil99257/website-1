Put real fleet photos here (WebP, about 1200x750), then set `image: '/images/fleet/your-photo.webp'`
and `isIllustrative: false` for that vehicle in src/config/fleet.ts.
