Put the company's real logo file here (SVG or PNG with transparent background), e.g. logo.svg,
then set business.logoSrc = '/brand/logo.svg' (plus logoWidth / logoHeight) in src/config/business.ts.
No logo file was supplied, so the site currently shows the business name as text.
