# API — Jay Nejadhari Tours and Travels

> Reads PRD.md, ARCHITECTURE.md and DATABASE.md.

## v1: no server API
The site is a static export. All "endpoints" are **outbound deep links** opened by the visitor's device. They are defined once in `src/lib/whatsapp.ts` and every component uses those helpers.

### 1. Phone call
| | |
|---|---|
| Method | Navigation (`<a href>`) |
| URL | `tel:+917567717570` |
| Purpose | Call Now buttons (hero, header, floating bar, footer, form fallback) |
| Auth | No |
| Maps to | PRD feature 2, 10, 11 · config `business.phoneE164` |

### 2. WhatsApp quick enquiry
| | |
|---|---|
| Method | Navigation, `target="_blank" rel="noopener"` |
| URL | `https://wa.me/917567717570?text=<urlencoded greeting>` |
| Purpose | WhatsApp Inquiry buttons (no form) |
| Auth | No |
| Request example | text = "Namaste Jay Nejadhari Tours and Travels, I would like to enquire about a trip." (translated per language) |
| Maps to | PRD 2, 10, 11 · `business.whatsappE164` |

### 3. WhatsApp formatted enquiry (form submit)
| | |
|---|---|
| Method | `window.open(url)` after client validation |
| URL | `https://wa.me/917567717570?text=<urlencoded message>` |
| Purpose | Plan Your Journey form |
| Input (validated) | `name` (2–80 chars) · `phone` (10-digit Indian mobile, optional +91/0) · `pickup` (2–120) · `destination` (2–120) · `date` (today or later) · `passengers` (1–500) · `seating` (fleet id or "any") · `tripType` (service id) · `notes` (≤ 500) |
| Success example (EN) | see below |
| Errors | Client-side only, shown inline: `required`, `invalidPhone`, `pastDate`, `passengersRange`, `tooLong` — one standard shape `{ field, code }` mapped to translated text |
| Maps to | PRD 9 · DATABASE "INQUIRY" (not stored) |

```
*New Travel Enquiry* 🚐
Jay Nejadhari Tours and Travels

👤 Name: Hetal Patel
📞 Phone: 98xxxxxx10
📍 Pickup: Adajan, Surat
🏁 Destination: Dwarka
📅 Travel date: 24 Dec 2026
👥 Passengers: 14
💺 Preferred seating: 17 Seater
🧭 Trip type: Pilgrimage and Religious Tours
📝 Requirements: AC, 2 nights

Sent from the website (EN)
```
Labels in the message follow the visitor's chosen language.

## Standards
- Single standard error format `{ field: keyof Inquiry, code: ErrorCode }`.
- Versioning: if a server API is added later, prefix `/api/v1/…`.
- Rate limiting: N/A (no server). If enquiry logging (V2) is added: `POST /api/v1/inquiries`, 5 req/min/IP, body = the validated fields above, `201 {id}` / `400 {errors:[{field,code}]}` / `429`.

## Mapping check
Every link maps to a PRD feature and a config field. Nothing unmapped.
