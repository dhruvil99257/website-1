# TESTING

> Reads PRD.md, FEATURES.md, API.md.

## 1. Tools
| Layer | Tool | File |
|---|---|---|
| Unit | Node built-in test runner (`node:test`, no extra dependency) | `tests/run-tests.mjs` |
| Type safety | TypeScript (missing translation keys fail) | `npm run typecheck` |
| End-to-end | Playwright (Chromium, mobile emulation) | `tests/e2e.cjs` |
| Performance / a11y / SEO | Lighthouse (mobile) | Chrome DevTools → Lighthouse |

## 2. Priorities (critical paths first)
1. Call & WhatsApp links use the correct number everywhere.
2. Enquiry form validates and builds the WhatsApp message correctly in all 3 languages.
3. Mobile layout at 320–430 px: no horizontal overflow, no overlap, tap targets ≥ 44 px.
4. Navigation & language switching.
5. Scrolling: native, backwards works, nothing pinned/snapped, reveals don't restart.
6. Reduced motion.
7. SEO tags and structured data.

## 3. Test cases per feature
### Enquiry form (F9)
| Scenario | Input | Expected |
|---|---|---|
| Empty submit | nothing | Error summary; 7 fields flagged; focus on Name |
| Bad phone | `12345` | "Please enter a valid 10-digit mobile number." |
| Phone formats | `+91 98250 12345`, `09825012345` | Accepted |
| Past date | yesterday | "Please choose today or a future date." |
| Passengers | `0`, `2.5`, `501` | Range error |
| Long notes | 501 chars | "This is too long." |
| Valid | all fields | wa.me/917567717570 opens with formatted message; success status shown |
| Prefill | tap Enquire on Bus/Coach | Seating = Bus / Coach, page scrolled to form |
### Navigation & language (F1)
| Scenario | Expected |
|---|---|
| Menu → Fleet | Drawer closes; Fleet heading 72 px from top (below header) |
| Esc in drawer | Closes, focus back on menu button |
| Switch to ગુજરાતી on #services | `/gu/#services`, `html lang="gu-IN"` |
| Revisit `/` | Redirects to saved language |
| Hindi page | No untranslated English headings/buttons/labels |
### Fleet / Map / Destinations
| Scenario | Expected |
|---|---|
| View details | `<dialog>` opens with correct vehicle; Esc/backdrop closes |
| Map pin / chip | Route highlights; caption updates |
| Gallery swipe | Horizontal swipe scrolls cards; vertical page scroll unaffected |
### Motion
| Scenario | Expected |
|---|---|
| Scroll to form then back to Fleet | Road un-draws; revealed cards stay visible |
| `prefers-reduced-motion` | All content visible immediately; road fully drawn; no vehicle |

## 4. Edge & negative tests
- Storage blocked (private mode): language switch still navigates.
- Pop-up blocked: WhatsApp opens in same tab.
- No JavaScript: all content and links visible (reveals are progressive enhancement).
- Slow network: text paints with fallback font first (`font-display: swap`), no layout shift (CLS ≈ 0).
- Unauthorized access: N/A (no accounts).

## 5. Test data & mocking
- Unit tests use a fixed date (18 Nov 2026) so date checks are stable.
- E2E mocks `window.open` so **no real WhatsApp message is ever sent** to the business number.

## 6. Coverage targets & commands
- `lib/whatsapp.ts` and `lib/validation.ts`: 100 % of branches exercised by unit tests.
```bash
npm run typecheck          # types + translation completeness
npm test                   # 7 unit tests
npm run build && npm start # in one terminal (serves http://localhost:3000)
npm i -D playwright && npx playwright install chromium   # first time only
npm run test:e2e           # in a second terminal — 28 browser checks
```

## 7. Results at delivery (18–19 Nov 2026)
- Unit: 7/7 pass. Typecheck: clean. Build: static export OK.
- E2E: 28/28 pass.
- Layout sweep: `/`, `/gu/`, `/hi/` at 320, 360, 375, 390, 414, 430, 768, 1024, 1440 px → no horizontal overflow, no hidden content, no console errors.
- Lighthouse mobile (local, compressed): Performance 83–94 · Accessibility 100 · Best practices 100 · SEO 100 · CLS ≈ 0.

## 8. Manual QA checklist (pre-release, on a real phone)
- [ ] Android Chrome + iPhone Safari: Call Now opens dialer with 75677 17570.
- [ ] WhatsApp Inquiry opens the app with the greeting.
- [ ] Submit the form once with your own test details → message arrives formatted (send it to yourself first by temporarily changing the number, then change back).
- [ ] Bottom Call/WhatsApp bar never covers the form button or footer text.
- [ ] Rotate phone to landscape: nothing overlaps.
- [ ] Swipe destinations with one finger; page still scrolls vertically.
- [ ] Switch EN → ગુજરાતી → हिन्दी → EN; text and fonts correct.
- [ ] Turn on "Reduce motion" (iOS: Settings → Accessibility → Motion) → site still complete.
- [ ] Share the URL on WhatsApp → preview image and title appear.
