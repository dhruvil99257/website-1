# DESIGN — Jay Nejadhari Tours and Travels

> Reads PRD.md as source of truth. Every UI must follow this file. Do not invent colours or fonts outside it.

## 1. Brand feel
**Modern Indian Travel** — the friendly confidence of a well-run family business on an open Indian highway at sunrise. Warm, colourful, clear; never luxury black-and-gold, never generic stock-template.

### Design principles
1. **Thumb first** — every decision is made for a 360 px phone held in one hand; desktop is an adaptation.
2. **The road tells the story** — one continuous illustrated road guides the visitor from the hero to the enquiry form.
3. **Honest & clear** — plain words, real facts only, illustrations labelled as illustrations.

## 2. Colour palette
| Token | Light | Dark (footer / dark surfaces) | Use |
|---|---|---|---|
| `navy` (primary) | `#173D5B` | `#0F2B41` | headings, header, primary surfaces |
| `saffron` (secondary/accent) | `#F3A43B` | `#F3A43B` | CTAs, highlights, road markings |
| `saffron-deep` | `#D9861A` | — | CTA hover, saffron text on light bg (AA large) |
| `green` (travel green) | `#4D8865` | `#6FAA86` | success, WhatsApp-adjacent accents, landscapes |
| `background` | `#F7F5EF` (warm white) | `#173D5B` | page background |
| `surface` | `#FFFFFF` | `#1F4A6B` | cards |
| `text` | `#242A30` (charcoal) | `#F7F5EF` | body text |
| `text-muted` | `#55606B` | `#C9D3DC` | secondary text |
| `success` | `#2F7A4F` | `#6FAA86` | form success |
| `warning` | `#B86E00` | `#F3A43B` | notices |
| `error` | `#C0392B` | `#FF8A7A` | form errors |
| `whatsapp` | `#15803D` (hover `#116932`) | — | WhatsApp button only — a deeper WhatsApp-style green so white text passes AA (5.0:1) |

The site uses a single light theme with navy "dark" bands (header on scroll, footer, map section). A full OS dark mode is not applied — the warm-white brand surface is part of the identity.

Contrast: charcoal on warm white 13.9:1; white on navy 11.6:1; navy on saffron 5.9:1 (CTA text is navy on saffron, never white on saffron).

## 3. Typography
| Role | Latin / Hindi (Devanagari) | Gujarati |
|---|---|---|
| Display / headings | **Baloo 2** 600–800 | **Baloo Bhai 2** 600–800 |
| Body / UI | **Mukta** 400/500/700 | **Hind Vadodara** 400/500/700 |

Fonts are self-hosted (Fontsource, `unicode-range` subsets) so only glyphs used on the page download.

Scale (mobile → desktop, fluid `clamp`):
| Token | Mobile | Desktop | Line-height | Weight |
|---|---|---|---|---|
| display | 2.25rem | 4.25rem | 1.05 | 800 |
| h2 | 1.75rem | 2.75rem | 1.15 | 700 |
| h3 | 1.2rem | 1.4rem | 1.25 | 700 |
| body-lg | 1.0625rem | 1.2rem | 1.6 | 400 |
| body | 1rem | 1rem | 1.6 | 400 |
| small | 0.875rem | 0.875rem | 1.5 | 500 |
| eyebrow | 0.8rem uppercase, tracking 0.14em | | | 700 |

Minimum body size on mobile: 16 px (prevents iOS input zoom too).

## 4. Spacing, radius, shadow, breakpoints
- Spacing scale (4 px base): 4, 8, 12, 16, 20, 24, 32, 40, 56, 72, 96.
- Section padding: 64 px mobile / 96 px desktop vertical; 16 px side gutter mobile, 24 px tablet, max content width 1200 px.
- Radius: `sm 8px` inputs · `md 14px` buttons · `lg 22px` cards · `full` pills.
- Shadows (cheap, no blur stacking):
  - `card`: `0 6px 18px -8px rgba(23,61,91,.25)`
  - `lift`: `0 16px 32px -14px rgba(23,61,91,.35)`
  - `cta`: `0 8px 18px -8px rgba(217,134,26,.6)`
- Breakpoints (Tailwind): `xs 360` · `sm 480` · `md 768` · `lg 1024` · `xl 1280`.
- Mobile test widths: 320, 360, 375, 390, 414, 430.
- No `backdrop-filter` except the header (single small element); falls back to solid navy.

## 5. Components (all states)
### Buttons
| Variant | Default | Hover (pointer) | Focus | Active (tap) | Disabled | Loading |
|---|---|---|---|---|---|---|
| Primary (Call) | saffron bg, navy text, `cta` shadow | `saffron-deep` bg, lift −2px | 3 px navy ring + 2 px offset | scale .97 | 45 % opacity, no shadow | spinner + label "Opening…" |
| WhatsApp | `whatsapp` bg, white text | darken 8 % | 3 px navy ring | scale .97 | 45 % | spinner |
| Secondary | transparent, 2 px navy border | navy bg, white text | ring | scale .97 | 45 % | — |
| Ghost (on dark) | white 2 px border, white text | white bg navy text | saffron ring | scale .97 | 45 % | — |
Min height 48 px, min width 48 px, padding 14×22, radius `md`, icon 20 px + 8 px gap.

### Inputs
Height 52 px, radius `sm`, 1.5 px border `#CBD2D9`, white bg, 16 px text, label above (always visible).
States: hover border navy 50 %; focus border navy + 3 px saffron/40 ring; error border `error` + message below with icon, `aria-invalid`; disabled grey bg.

### Cards
Surface white, radius `lg`, `card` shadow. Fleet cards: illustration area 16:10, image zoom 1.06 on hover/focus, 3D tilt ≤ 6° on pointer devices only. Service cards: coloured top illustration band, icon, title, 2-line description.

### Modal (vehicle details)
Native `<dialog>`; full-width bottom sheet on mobile (radius top 22 px), centred 560 px on desktop; focus trapped by dialog; Esc and backdrop close; close button 44 px.

### Navbar
Transparent over hero → solid navy after 40 px scroll. Height 64 px mobile / 72 px desktop. Mobile: logo + language pill + 48 px menu button → full-height drawer with large links. Desktop: inline links + language select + Call button.

### Language selector
Pill showing current script ("EN / ગુ / हि"); opens a small list with native names. Current language marked with `aria-current`.

### Toast / inline status
Form success/failure shown inline above the submit button (role="status"), green/red left border. No floating toasts.

### Floating action bar
Mobile (< 768 px): fixed bottom bar, 64 px + safe-area inset, two equal buttons (Call / WhatsApp). The page has bottom padding equal to the bar so content is never covered. Hidden while the enquiry form's submit button is on screen. Desktop: two 56 px round buttons bottom-right.

### Tables
Not used in v1.

## 6. Page layout (single page, section order)
1. **Header** (sticky)
2. **Hero** — mobile: logo badge, eyebrow "Surat · All India", headline, subtitle, two full-width CTAs stacked, illustrated highway fills the lower 45 % of the viewport. Desktop: text left, scene full-bleed behind.
3. **Discover India** — navy band; map full-width on mobile with destination chips below; desktop map left / highlights right.
4. **Our Fleet** — 1 column (320–479), 2 columns (480+), 3 columns (1024+).
5. **Our Services** — 1 / 2 / 3 / 4 columns.
6. **Explore Destinations** — horizontal scroll-snap (proximity) row, cards 78 vw on mobile, 320 px on desktop; arrow buttons on desktop.
7. **Why Choose Us** — 2×2 grid of illustrated strengths.
8. **Customer Reviews** — empty state card until reviews exist; then swipe row.
9. **Plan Your Journey** — form in a white card on a saffron-tinted band; 1 column mobile, 2 columns ≥ 768.
10. **Footer** — navy; columns stack on mobile.

The **signature road** is an SVG line running down the left gutter (mobile) / centre-left (desktop) behind sections 2–9, drawn by scroll progress, ending at the form with a destination pin.

## 7. Motion
- Easing `power3.out`; durations 0.5–0.9 s; stagger 0.08 s.
- Only `transform` and `opacity` animate (plus SVG `stroke-dashoffset`).
- Scroll animations are **scrubbed or one-shot**, never pinned on screens < 768 px, never hijack scroll.
- `prefers-reduced-motion: reduce` → everything visible instantly, road fully drawn, no tilt/parallax, wheel-dash animation stopped.
- Low-power hint (`navigator.hardwareConcurrency <= 4` or Save-Data) → parallax and tilt disabled.

## 8. Accessibility rules
- WCAG 2.1 AA contrast (see §2).
- Visible focus ring on every interactive element (`:focus-visible`, 3 px).
- Skip link "Skip to content".
- All controls keyboard reachable; drawer closes with Esc and returns focus.
- Touch targets ≥ 44×44 px.
- `lang` attribute matches the active language; form inputs have labels; errors linked with `aria-describedby`.
- Decorative SVGs `aria-hidden`; meaningful illustrations have translated `alt`/`aria-label`.
