# FEATURES — build guide per MVP feature

> Reads PRD.md, PLAN.md, API.md, DATABASE.md. Built one at a time; each acceptance list was verified (see TESTING.md for the automated checks).

---
## F1. Header, mobile menu & language switcher
**User story:** As a family planner, I want to read the site in Gujarati, so that I fully understand it.
**Components:** `Header.tsx`, `LanguageSwitcher.tsx`, `Logo.tsx` (DESIGN §5 Navbar, Language selector).
**Data:** `config/nav.ts`, `i18n/*.nav`. No API.
**Build order:** sticky header → transparent→navy on scroll → desktop links → language dropdown → mobile drawer with focus trap → language restore.
**Edge cases:** storage blocked (private mode) → switch still works, just not remembered; Esc closes drawer and returns focus; body scroll locked while drawer open.
**Acceptance**
- [x] Drawer opens/closes with button and Esc; links close it and land below the header.
- [x] Switching language keeps the current section (`/gu/#services`).
- [x] Returning to `/` reopens the saved language.
- [x] `<html lang>` matches the language.

## F2. Hero
**User story:** As any visitor, I want to understand the business in seconds and call immediately.
**Components:** `Hero.tsx`, `HighwayScene.tsx`. **API:** tel / wa.me (API.md 1–2).
**Build order:** text block → CTAs → scene with reserved height → CSS entrance → parallax (desktop/capable devices).
**Edge cases:** very short screens (scene sits below text, never overlaps); no JS (everything visible); reduced motion (no animation).
**Acceptance**
- [x] Headline, subtitle, Call Now and WhatsApp Inquiry visible on first screen at 320–430 px.
- [x] Headline painted immediately (no JS dependency) for fast LCP.
- [x] Logo shows automatically when `business.logoSrc` is set.

## F3. Discover India map
**Components:** `DiscoverIndia.tsx`, `IndiaMap.tsx`, `lib/geo.ts`, `public/images/india-map.svg`.
**Data:** `config/destinations.ts` (lat/lon).
**Build order:** outline image → coverage dots → routes (Bézier from Surat) → pins (keyboard-operable) → chips → caption with "Plan a trip here".
**Edge cases:** reduced motion → routes drawn, no moving dot; small screens → chips below map.
**Acceptance**
- [x] Routes draw once when the map scrolls into view.
- [x] Tapping a pin or chip highlights its route and updates the caption.
- [x] "Plan a trip here" pre-fills destination.

## F4. Fleet
**User story:** As a family planner, I want to see seat sizes, so that I book a vehicle that fits everyone.
**Components:** `Fleet.tsx`, `FleetGrid.tsx`, `VehicleArt.tsx`, `lib/useTilt.ts`.
**Data:** `config/fleet.ts` + `i18n.fleet.items`.
**Edge cases:** missing translation → falls back to id (TypeScript flags it first); real photo set → used instead of illustration; illustration → "Illustrative image" badge.
**Acceptance**
- [x] Cards 1 / 2 / 3 columns at 320 / 480 / 1024 px.
- [x] Tilt only on mouse devices; zoom on hover/focus.
- [x] View details opens an accessible bottom sheet (Esc/backdrop close).
- [x] Enquire selects seating and scrolls to the form.

## F5. Services
**Components:** `Services.tsx`, `ServiceArt.tsx`, `PrefillButton.tsx`. **Data:** `config/services.ts`.
**Acceptance**
- [x] 7 cards with distinct illustrations, translated.
- [x] "Ask about this" pre-selects trip type; footer service links jump to each card.

## F6. Explore Destinations
**Components:** `Destinations.tsx`, `GalleryRail.tsx`, `DestinationArt.tsx`.
**Edge cases:** native finger swipe with proximity snap only (never forced); arrows disabled at ends; vertical page scroll is never blocked.
**Acceptance**
- [x] Swipe works on touch; arrows on desktop; "Plan a trip here" pre-fills destination.

## F7. Why Choose Us
**Acceptance**
- [x] Only the 4 verified strengths; no counters (no numeric data supplied).

## F8. Customer Reviews
**Data:** `config/reviews.ts` (empty by default).
**States:** empty → honest "Reviews coming soon" + share-feedback WhatsApp link; filled → swipe row with name, place, source.
**Acceptance**
- [x] No generated reviews or ratings anywhere (UI, JSON-LD).

## F9. Plan Your Journey (inquiry → WhatsApp)
**User story:** As a corporate admin, I want to send trip details in one message, so that I get a quotation quickly.
**Components:** `PlanJourney.tsx`, `InquiryForm.tsx`, `lib/validation.ts`, `lib/whatsapp.ts`.
**Validation:** API.md §3. **States:** idle · error (summary + inline, focus first invalid) · opening (spinner) · sent (success + open again + call instead).
**Edge cases:** pop-up blocked → same-tab navigation; date min = today (client-side); phone accepts +91/0 prefixes; notes ≤ 500.
**Acceptance**
- [x] Empty submit shows errors and focuses the first invalid field.
- [x] Valid submit opens `https://wa.me/917567717570?text=…` with all details, labels in the page language.

## F10. Footer & floating actions
**Acceptance**
- [x] Footer: name, Surat, phone, WhatsApp, language buttons, service links; socials/address/email only when configured.
- [x] Mobile bar hides while hero CTAs or form submit are visible; page reserves its height so nothing is covered.

## F11. Signature road
**Components:** `SignatureRoad.tsx`.
**Acceptance**
- [x] Road draws with scroll, un-draws when scrolling back, ends at the form with a pin.
- [x] Stays in gutters; crosses only in section padding; never pins or snaps.
- [x] Reduced motion → fully drawn, no vehicle.

## F12. SEO & accessibility
**Acceptance**
- [x] Unique title/description per language, canonical + hreflang, OG image, JSON-LD (verified fields only), sitemap.xml, robots.txt.
- [x] Lighthouse Accessibility 100, SEO 100.
