# DATABASE — Jay Nejadhari Tours and Travels

> Reads PRD.md and ARCHITECTURE.md.

## v1 decision: no database
PRD non-goals exclude bookings, accounts and payments, and enquiries travel through WhatsApp. A database would add cost, security surface and maintenance with no user benefit. **Content is stored in typed configuration files** under `src/config/` and `src/i18n/`, which act as the "tables" of this site and are compiled into static pages at build time.

## Content "tables" (config files)
| File | Record type | Fields |
|---|---|---|
| `business.ts` | single object | `name`, `city`, `state`, `country`, `phoneDisplay`, `phoneE164`, `whatsappE164`, `addressLine` (placeholder), `mapsUrl` (placeholder), `email` (optional), `socials[]` (empty until supplied), `siteUrl` |
| `fleet.ts` | `Vehicle[]` | `id` (slug), `seats` (number or `{min,max}`), `art` (illustration key), `image?` (real photo path), `isIllustrative` (bool), text per language in `i18n` |
| `services.ts` | `Service[]` | `id`, `art`, `accent` |
| `destinations.ts` | `Destination[]` | `id`, `art`, `map: {x,y}` pin position, `region` |
| `reviews.ts` | `Review[]` | `id`, `name`, `place?`, `text`, `lang`, `date`, `source` (e.g. "Google", "WhatsApp"), `verified: true` — **empty array by default** |

Rules carried over from the workflow spec: consistent naming (camelCase in TS), every record has a stable `id`; nothing is "deleted" from history — remove a vehicle by setting `active: false`.

## Relationships
```mermaid
erDiagram
    BUSINESS ||--o{ VEHICLE : operates
    BUSINESS ||--o{ SERVICE : offers
    BUSINESS ||--o{ DESTINATION : covers
    BUSINESS ||--o{ REVIEW : receives
    VEHICLE }o--o{ SERVICE : "used for"
    INQUIRY }o--|| VEHICLE : "prefers seating"
    INQUIRY }o--|| SERVICE : "trip type"
```
`INQUIRY` is not stored — it exists only as the WhatsApp message.

## Future (V2/Later) — if enquiry logging is added
Use Supabase (Postgres) or a Google Sheet. Proposed table:

| Column | Type | Constraints |
|---|---|---|
| `id` | uuid | PK, default `gen_random_uuid()` |
| `customer_name` | text | not null, ≤ 80 |
| `phone` | text | not null, 10-digit Indian mobile |
| `pickup_location` | text | not null |
| `destination` | text | not null |
| `travel_date` | date | not null, ≥ today |
| `passengers` | int | not null, 1–56 |
| `seating_preference` | text | nullable |
| `trip_type` | text | not null, enum of services |
| `notes` | text | nullable, ≤ 500 |
| `language` | text | `en`/`gu`/`hi` |
| `created_at` | timestamptz | default now() |
| `updated_at` | timestamptz | default now() |
| `deleted_at` | timestamptz | nullable (soft delete) |

Indexes: `(created_at desc)`, `(travel_date)`. RLS: insert-only for `anon`; select/update for `owner` role only. Migration order: 1) create table, 2) RLS policies, 3) indexes. No seed data (real enquiries only).
