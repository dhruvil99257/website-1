import type { Config } from 'tailwindcss';

// Tokens mirror DESIGN.md — do not add colours or fonts outside it.
const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    screens: { xs: '360px', sm: '480px', md: '768px', lg: '1024px', xl: '1280px' },
    extend: {
      colors: {
        navy: { DEFAULT: '#173D5B', deep: '#0F2B41', soft: '#1F4A6B', line: '#2C5A7E' },
        saffron: { DEFAULT: '#F3A43B', deep: '#D9861A', soft: '#FCE9CC' },
        green: { DEFAULT: '#4D8865', light: '#6FAA86', soft: '#DCEBE1' },
        cream: '#F7F5EF',
        charcoal: '#242A30',
        muted: '#55606B',
        success: '#2F7A4F',
        warning: '#B86E00',
        error: '#C0392B',
        whatsapp: { DEFAULT: '#15803D', deep: '#116932' },
      },
      fontFamily: {
        display: ['var(--font-display)'],
        body: ['var(--font-body)'],
      },
      borderRadius: { sm: '8px', md: '14px', lg: '22px' },
      boxShadow: {
        card: '0 6px 18px -8px rgba(23,61,91,.25)',
        lift: '0 16px 32px -14px rgba(23,61,91,.35)',
        cta: '0 8px 18px -8px rgba(217,134,26,.6)',
      },
      maxWidth: { content: '1200px' },
    },
  },
  plugins: [],
};

export default config;
