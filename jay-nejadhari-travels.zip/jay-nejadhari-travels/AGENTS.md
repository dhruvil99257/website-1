# AGENTS.md — rules for any AI coding assistant in this repo

## Project summary
1. Mobile-first marketing website for **Jay Nejadhari Tours and Travels**, Surat, Gujarat.
2. Own fleet 4–56 seats, All India trips, per-km negotiated pricing.
3. Goal: Call / WhatsApp enquiries from Indian families and businesses.
4. Static Next.js 15 + TypeScript + Tailwind + GSAP; no backend, no database.
5. Three languages on static routes: `/` (EN), `/gu/`, `/hi/`.

## Source-of-truth files (priority order)
1. PRD.md  2. DESIGN.md  3. ARCHITECTURE.md  4. DATABASE.md  5. API.md
Then: PLAN.md, FEATURES.md, AUTH_SECURITY.md, TESTING.md.

## DO
- Follow the folder structure in ARCHITECTURE.md.
- Put all business facts in `src/config/*` and all UI text in `src/i18n/*` (all 3 languages).
- Reuse existing pieces: `data-reveal` attribute for scroll reveals, `Icons.tsx`, `PrefillButton`, button classes `btn-*`, `.card`, `.field`.
- Write small focused functions; comment non-obvious animation logic.
- Handle loading, empty and error states (reviews empty state, form errors).
- Design for 320 px first; check 320/360/375/390/414/430 before calling work done.
- Animate only `transform`, `opacity`, `stroke-dashoffset`; respect `prefers-reduced-motion`.
- Keep tap targets ≥ 44 px.

## DO NOT
- Do not change the tech stack.
- Do not add new libraries without asking the owner.
- Do not change config shapes without updating DATABASE.md.
- Do not delete or rewrite working code unless asked.
- Do not hardcode secrets (there are none in v1 — keep it that way).
- **Never invent business facts**: phone numbers, addresses, reviews, ratings, statistics, vehicle models, or claim illustrations are real fleet photos.
- Do not hijack scroll, add scroll snapping between sections, or pin sections on mobile.
- Do not leave buttons that look clickable but do nothing.
- Do not use colours or fonts outside DESIGN.md.

## Workflow
1. Plan — say which files you will touch and why.
2. Code — smallest change that satisfies the request.
3. Verify — `npm run typecheck && npm test && npm run build` (and `npm run test:e2e` for UI changes).
4. Summarise — short list of what changed.

## Conflicts
If a request conflicts with any source-of-truth file, **stop and ask** before proceeding.
