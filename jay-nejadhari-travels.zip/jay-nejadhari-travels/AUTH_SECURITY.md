# AUTH & SECURITY

> Reads PRD.md, ARCHITECTURE.md, DATABASE.md, API.md.

## 1. Authentication — not used in v1
There are no user accounts, logins, admin panel, payments or stored personal data (PRD non-goals). Therefore **no login/signup/logout/password-reset flows, JWTs, refresh tokens or roles exist** — every visitor has the same public, read-only access. This removes the largest classes of risk entirely.

If an admin area or enquiry log is added later (V2):
| Item | Choice | Why |
|---|---|---|
| Auth method | Supabase Auth magic link (email) for the owner only | No passwords to leak or forget |
| Session | httpOnly, Secure, SameSite=Lax cookie; access token 15 min, refresh 7 days, rotated on use | Tokens never readable by page scripts |
| Roles | `owner` (read/update enquiries), `anon` (insert enquiry only) | Least privilege; enforced with Postgres RLS |
| Rate limit | 5 enquiries/min/IP on `POST /api/v1/inquiries` | Stops spam floods |

## 2. Roles & permissions matrix (v1)
| Action | Visitor |
|---|---|
| View pages | ✅ |
| Open tel: / WhatsApp links | ✅ |
| Submit enquiry (goes to visitor's own WhatsApp) | ✅ |
| Change content | ❌ (only via code/config + redeploy) |

## 3. Data handling
- Form data never leaves the visitor's browser except inside the WhatsApp message **the visitor chooses to send**. Nothing is stored, logged or sent to a server. The form says so.
- No cookies, no analytics, no third-party scripts, no external fonts.
- `localStorage` holds only the chosen language (`jnt-lang`).

## 4. Web protections
| Threat | Protection |
|---|---|
| XSS | React escapes all text; no user input is ever rendered as HTML; the only `dangerouslySetInnerHTML` uses are static (boot script, JSON-LD with `<` escaped). |
| Injection into WhatsApp message | Message is built from plain strings and passed through `encodeURIComponent`. |
| Tab-nabbing | External links use `rel="noopener noreferrer"`; `window.open` result has `opener` cleared. |
| CSRF | No state-changing server endpoints exist. |
| CORS | No API; nothing to expose. |
| Clickjacking | Add header `X-Frame-Options: DENY` / CSP `frame-ancestors 'none'` at the host (see below). |
| Spam | Enquiries go to a human via WhatsApp; nothing is auto-processed. |

## 5. Input validation (client-side, `lib/validation.ts`)
- Name 2–80 chars · Pickup/Destination 2–120 · Notes ≤ 500 (also `maxLength` on inputs).
- Phone: Indian mobile `[6-9]` + 9 digits, optional `+91`/`0`/`091` prefix.
- Date ≥ today · Passengers integer 1–500 · Trip type from fixed list · Seating from fixed list.

## 6. Secrets & environment variables
- v1 has **no secrets**. Phone/WhatsApp numbers are public business contacts kept in `src/config/business.ts`.
- `NEXT_PUBLIC_SITE_URL` is public by design.
- `.env*.local` is git-ignored. Never put API keys in `NEXT_PUBLIC_*` variables.

## 7. Recommended host security headers
Netlify `_headers` / Vercel `vercel.json` / Apache `.htaccess` equivalent:
```
Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'
X-Content-Type-Options: nosniff
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: camera=(), microphone=(), geolocation=()
Strict-Transport-Security: max-age=31536000; includeSubDomains
```
(`'unsafe-inline'` is needed for Next's inline hydration data and the tiny boot script.)

## 8. Pre-launch security checklist
- [ ] HTTPS enabled on the domain (free with all recommended hosts).
- [ ] Security headers above configured.
- [ ] `NEXT_PUBLIC_SITE_URL` set to the real https domain.
- [ ] Phone/WhatsApp number in `business.ts` confirmed by the owner.
- [ ] `npm audit` reviewed; Next.js on a patched version (currently 15.5.29).
- [ ] No test data or placeholder reviews in `reviews.ts`.
- [ ] Social links point to official accounts only.
