# Jay Nejadhari Tours and Travels — Website

**Your Journey, Our Responsibility.** A mobile-first, trilingual (English · ગુજરાતી · हिन्दी) website for a Surat-based travel business with its own fleet of 4 to 56 seater vehicles and All India service.

> Screenshots: _add `docs/screenshot-mobile.png` and `docs/screenshot-desktop.png` after deployment._

## Key features
- Hero with an illustrated Indian highway, animated road and one-tap **Call Now** / **WhatsApp Inquiry**.
- **Signature road** that draws itself as you scroll, from the hero down to the enquiry form.
- Interactive SVG **India map** with routes from Surat to popular destinations.
- **Fleet** catalogue (editable) with tilt cards, details sheet and "Enquire" that pre-fills the form.
- 7 **services**, swipeable **destinations** gallery, **Why choose us**, honest **reviews** section (real reviews only).
- **Plan Your Journey** form → validated → opens WhatsApp with a formatted message to +91 75677 17570.
- Floating Call/WhatsApp bar on phones that never covers content.
- Real language switcher with separate URLs (`/`, `/gu/`, `/hi/`) and a remembered choice.
- Reduced-motion support, keyboard accessible, SEO metadata, hreflang, LocalBusiness JSON-LD, sitemap, robots.

## Tech stack
Next.js 15 (App Router, static export) · React 19 · TypeScript · Tailwind CSS 3 · GSAP 3 + ScrollTrigger · inline SVG illustrations · self-hosted fonts (Mukta, Baloo 2, Hind Vadodara, Baloo Bhai 2).

## Quick start
1. Install Node.js 22 or newer.
2. `npm install`
3. `cp .env.example .env.local` and set your domain (Windows: `copy .env.example .env.local`).
4. `npm run dev` → open http://localhost:3000
5. To publish: `npm run build` → upload the `out/` folder to any static host.

## Environment variables
| Name | Purpose | Example |
|---|---|---|
| `NEXT_PUBLIC_SITE_URL` | Canonical URL used in sitemap, hreflang and structured data | `https://www.example.com` |

## Where to edit content
| What | File |
|---|---|
| Phone, WhatsApp, address, email, logo, social links | `src/config/business.ts` |
| Vehicle categories and seat ranges | `src/config/fleet.ts` (+ names in `src/i18n/*.ts → fleet.items`) |
| Destinations and map pins | `src/config/destinations.ts` |
| Customer reviews (real ones only) | `src/config/reviews.ts` |
| All text in each language | `src/i18n/en.ts`, `gu.ts`, `hi.ts` |
| Logo file | `public/brand/` then set `logoSrc` in `business.ts` |

## Folder structure
```
src/app         language routes (/, /gu/, /hi/), sitemap, robots, global styles
src/components  page sections and UI pieces
src/config      business facts and catalogue (edit here)
src/i18n        translations (typed — a missing key fails the build)
src/lib         WhatsApp links, validation, SEO helpers, geo
public          logo, fonts, map image, favicon, social image
tests           unit tests (node:test) and browser tests (Playwright)
scripts         font and map generators
```
Full details: [ARCHITECTURE.md](ARCHITECTURE.md).

## Scripts
| Command | What it does |
|---|---|
| `npm run dev` | Development server on http://localhost:3000 |
| `npm run build` | Production static build into `out/` |
| `npm start` | Serves `out/` on http://localhost:3000 (after build) |
| `npm run typecheck` | TypeScript check |
| `npm test` | Unit tests (WhatsApp message + form validation) |
| `npm run test:e2e` | Browser tests (needs Playwright, see TESTING.md) |
| `npm run fonts` | Regenerate self-hosted font subsets |
| `npm run map` | Regenerate the India map image |

## Before launch (owner to supply)
Logo file · full address / Google Maps link · confirmed fleet categories · social accounts · domain · native-speaker review of Gujarati and Hindi text. See PLAN.md → Phase 6.

## Contributing
Read [AGENTS.md](AGENTS.md) first. Keep changes small, mobile-first, and never add invented business facts. Run `npm run typecheck && npm test && npm run build` before sharing changes.

## License & credits
Website code: © Jay Nejadhari Tours and Travels, all rights reserved.
India map outline: [SVG Maps](https://github.com/VictorCazanave/svg-maps) by Victor Cazanave, CC BY 4.0 (simplified).
Fonts: Mukta, Baloo 2, Hind Vadodara, Baloo Bhai 2 — SIL Open Font License.
Illustrations are original and representative; they do not show actual fleet vehicles.
