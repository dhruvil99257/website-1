// Regenerates public/images/india-map.svg from src/components/map/indiaPaths.ts.
// The outline is served as a cached static image so it is not repeated inside every HTML page.
// Run: node scripts/build-india-map.mjs
import { readFileSync, writeFileSync } from 'node:fs';
const src = readFileSync(new URL('../src/components/map/indiaPaths.ts', import.meta.url), 'utf8');
const states = JSON.parse(src.slice(src.indexOf('= [') + 2, src.lastIndexOf(']') + 1));
const paths = states
  .map((s) => `<path d="${s.path}" fill="${s.id === 'gj' ? '#2A6A8C' : '#1F4A6B'}" stroke="${s.id === 'gj' ? '#F3A43B' : '#3A6C92'}" stroke-width="${s.id === 'gj' ? 1.6 : 0.8}" stroke-linejoin="round"/>`)
  .join('');
const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 612 696" width="612" height="696"><!-- India outline: SVG Maps by Victor Cazanave, CC BY 4.0 (simplified) -->${paths}</svg>`;
writeFileSync(new URL('../public/images/india-map.svg', import.meta.url), svg);
console.log('wrote public/images/india-map.svg', svg.length, 'bytes');
