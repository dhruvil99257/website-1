# PLAN — implementation roadmap

> Reads PRD.md, ARCHITECTURE.md, DATABASE.md, API.md. App is runnable after every phase. Vertical slices.

## Phase 1 — Foundation
- [x] 1.1 Scaffold Next.js 15 + TS + Tailwind, static export — `package.json`, `next.config.mjs`, `tailwind.config.ts` · verify: `npm run build` produces `out/`.
- [x] 1.2 Design tokens + fonts — `tailwind.config.ts`, `globals.css`, `layout.tsx` · verify: headings render in Baloo, body in Mukta.
- [x] 1.3 Central config — `src/config/*` · verify: typecheck passes. *(dep: 1.1)*
- [x] 1.4 i18n dictionaries EN/GU/HI with typed keys — `src/i18n/*` · verify: missing key = TS error. *(dep: 1.3)*
**DoD:** blank page builds in 3 languages at `/`, `/gu/`, `/hi/`.

## Phase 2 — Conversion core (Auth phase N/A — no accounts, see AUTH_SECURITY.md)
- [x] 2.1 `lib/whatsapp.ts`, `lib/validation.ts` + unit tests · verify: `npm test` green.
- [x] 2.2 Header, mobile drawer, language switcher · verify: drawer opens/closes with button & Esc; language change keeps section hash.
- [x] 2.3 Hero with Call/WhatsApp CTAs + highway scene · verify: `tel:` and `wa.me` links correct.
- [x] 2.4 Floating action bar · verify: never covers footer/form submit at 320 px.
- [x] 2.5 Inquiry form → WhatsApp · verify: message formatted per API.md in all 3 languages.
**DoD:** a visitor can call or send a complete WhatsApp enquiry on a 320 px phone.

## Phase 3 — Core content
- [x] 3.1 Fleet catalogue + cards + details dialog + Enquire prefill · verify: Enquire selects seating & scrolls to form.
- [x] 3.2 Services (7 cards with art).
- [x] 3.3 Destinations swipe gallery + "Plan a trip" prefill.
- [x] 3.4 Discover India map with routes & pins.
- [x] 3.5 Why Choose Us (4 verified strengths, no counters).
- [x] 3.6 Reviews (config-driven, empty state).
- [x] 3.7 Footer with service links, socials only if configured, map attribution.
**DoD:** all 9 homepage sections present and translated.

## Phase 4 — Integrations
- [x] 4.1 WhatsApp + tel deep links centralised (only integrations in v1) — see INTEGRATIONS.md.

## Phase 5 — Polish (animation, performance, SEO)
- [x] 5.1 AnimationProvider: GSAP registration, reveal batching, reduced-motion & low-power modes.
- [x] 5.2 Signature road drawn by scroll progress (scrubbed, never pinned).
- [x] 5.3 Hero entrance, map route drawing, card tilt/zoom, parallax (desktop only).
- [x] 5.4 SEO: metadata, hreflang, JSON-LD (verified fields only), sitemap, robots, OG image.
- [x] 5.5 Accessibility pass: skip link, focus rings, labels, contrast.
**DoD:** Lighthouse mobile targets in PRD §8; reduced-motion shows static complete page.

## Phase 6 — Launch
- [ ] 6.1 Owner supplies logo → replace `public/brand/logo.svg`.
- [ ] 6.2 Owner confirms fleet categories, address, socials, domain → update `src/config/business.ts`, `fleet.ts`, `.env`.
- [ ] 6.3 Native speaker reviews `gu.ts` and `hi.ts`.
- [ ] 6.4 Deploy `out/` to host; submit sitemap to Google Search Console; create Google Business Profile.
**DoD:** live on the real domain with real logo and confirmed details.
