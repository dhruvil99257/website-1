// Unit tests for the WhatsApp message builder and inquiry validation (TESTING.md).
// Run: npm test   (Node 22+ strips TypeScript types natively)
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildInquiryMessage, waLink, telLink, formatTravelDate } from '../src/lib/whatsapp.ts';
import { validateInquiry, normalizeIndianMobile, emptyInquiry, todayISO } from '../src/lib/validation.ts';

const NOW = new Date(2026, 10, 18, 12, 0, 0); // 18 Nov 2026
const valid = {
  ...emptyInquiry,
  name: 'Hetal Patel',
  phone: '98250 12345',
  pickup: 'Adajan, Surat',
  destination: 'Dwarka',
  date: '2026-12-24',
  passengers: '14',
  seating: 'traveller',
  tripType: 'pilgrimage',
};

test('tel and wa links use the configured number', () => {
  assert.equal(telLink('+917567717570'), 'tel:+917567717570');
  assert.equal(waLink('917567717570'), 'https://wa.me/917567717570');
  assert.equal(waLink('+91 75677 17570', 'Hi & bye'), 'https://wa.me/917567717570?text=Hi%20%26%20bye');
});

test('normalizes Indian mobile formats', () => {
  for (const ok of ['9825012345', '+91 98250 12345', '091-9825012345', '09825012345', '91 9825012345']) {
    assert.equal(normalizeIndianMobile(ok), '9825012345', ok);
  }
  for (const bad of ['12345', '5825012345', '98250123456', 'abcdefghij', '']) {
    assert.equal(normalizeIndianMobile(bad), null, bad);
  }
});

test('valid inquiry has no errors', () => {
  assert.deepEqual(validateInquiry(valid, NOW), []);
});

test('empty inquiry reports required fields (notes & seating optional)', () => {
  const fields = validateInquiry(emptyInquiry, NOW).map((e) => e.field).sort();
  assert.deepEqual(fields, ['date', 'destination', 'name', 'passengers', 'phone', 'pickup', 'tripType'].sort());
  assert.ok(validateInquiry(emptyInquiry, NOW).every((e) => e.code === 'required'));
});

test('rejects past date, bad phone, passenger range, long notes', () => {
  const errs = validateInquiry({ ...valid, date: '2026-11-17', phone: '12345', passengers: '0', notes: 'x'.repeat(501) }, NOW);
  const byField = Object.fromEntries(errs.map((e) => [e.field, e.code]));
  assert.equal(byField.date, 'pastDate');
  assert.equal(byField.phone, 'invalidPhone');
  assert.equal(byField.passengers, 'passengersRange');
  assert.equal(byField.notes, 'tooLong');
  assert.deepEqual(validateInquiry({ ...valid, date: todayISO(NOW) }, NOW), [], 'today is allowed');
  assert.equal(validateInquiry({ ...valid, passengers: '2.5' }, NOW)[0].code, 'passengersRange');
});

test('builds a formatted WhatsApp message and skips empty optional lines', () => {
  const labels = { heading: 'New Travel Enquiry', name: 'Name', phone: 'Phone', pickup: 'Pickup', destination: 'Destination', date: 'Travel date', passengers: 'Passengers', seating: 'Preferred seating', tripType: 'Trip type', notes: 'Requirements', footer: 'Sent from the website' };
  const msg = buildInquiryMessage('Jay Nejadhari Tours and Travels', labels, {
    name: 'Hetal Patel', phone: '98250 12345', pickup: 'Adajan, Surat', destination: 'Dwarka', date: '24 Dec 2026', passengers: '14', seating: 'Tempo Traveller — 12–20 seats', tripType: 'Pilgrimage & Religious Tours', notes: '  ',
  }, 'en');
  const lines = msg.split('\n');
  assert.equal(lines[0], '*New Travel Enquiry* 🚐');
  assert.equal(lines[1], 'Jay Nejadhari Tours and Travels');
  assert.ok(msg.includes('👤 Name: Hetal Patel'));
  assert.ok(msg.includes('🏁 Destination: Dwarka'));
  assert.ok(msg.includes('💺 Preferred seating: Tempo Traveller — 12–20 seats'));
  assert.ok(!msg.includes('Requirements'), 'empty notes line skipped');
  assert.equal(lines.at(-1), '_Sent from the website (EN)_');
});

test('formats travel date per language', () => {
  assert.match(formatTravelDate('2026-12-24', 'en-IN'), /24 Dec 2026/);
  assert.ok(formatTravelDate('2026-12-24', 'gu-IN').includes('2026') || formatTravelDate('2026-12-24', 'gu-IN').includes('૨૦૨૬'));
  assert.equal(formatTravelDate('bad', 'en-IN'), 'bad');
});
