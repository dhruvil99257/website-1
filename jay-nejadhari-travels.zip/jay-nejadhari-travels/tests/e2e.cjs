// End-to-end checks (TESTING.md). Needs a running build: npm run build && npm start (port 3000), then:
//   npm i -D playwright && npx playwright install chromium && node tests/e2e.cjs
// Set BASE=http://localhost:PORT to test another address.
const { chromium } = require('playwright');
const assert = (c, m) => { if (!c) throw new Error('FAIL: ' + m); console.log('PASS:', m); };
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 375, height: 740 }, hasTouch: true, isMobile: true });
  const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.addInitScript(() => { window.__opened = []; window.open = (u) => { window.__opened.push(u); return { opener: 1 }; }; });
  await p.goto((process.env.BASE || 'http://localhost:3000') + '/', { waitUntil: 'networkidle' });

  // Header logo on one line at 375
  // Call / WhatsApp links
  const tel = await p.$$eval('a[href^="tel:"]', as => [...new Set(as.map(a => a.getAttribute('href')))]);
  assert(tel.length === 1 && tel[0] === 'tel:+917567717570', 'all call links use tel:+917567717570 ' + JSON.stringify(tel));
  const wa = await p.$$eval('a[href*="wa.me"]', as => [...new Set(as.map(a => a.getAttribute('href').split('?')[0]))]);
  assert(wa.length === 1 && wa[0] === 'https://wa.me/917567717570', 'all WhatsApp links use 917567717570');

  // Mobile menu
  await p.click('button[aria-controls="mobile-nav"]');
  assert(await p.isVisible('#mobile-nav'), 'mobile drawer opens');
  await p.keyboard.press('Escape');
  assert(!(await p.isVisible('#mobile-nav')), 'drawer closes with Esc');
  await p.click('button[aria-controls="mobile-nav"]');
  await p.click('#mobile-nav a[href="#fleet"]');
  await p.waitForTimeout(1200);
  const fleetTop = await p.$eval('#fleet', el => el.getBoundingClientRect().top);
  assert(!(await p.isVisible('#mobile-nav')) && fleetTop >= 0 && fleetTop < 140, 'menu link scrolls to #fleet below sticky header (top=' + Math.round(fleetTop) + ')');

  // Vehicle dialog
  await p.click('#fleet article:nth-of-type(3) button:has-text("View details")');
  await p.waitForTimeout(400);
  assert(await p.$eval('dialog.sheet', d => d.open), 'vehicle details dialog opens');
  assert((await p.textContent('#vehicle-dialog-title')).includes('Tempo Traveller'), 'dialog shows the selected vehicle');
  await p.keyboard.press('Escape');
  assert(!(await p.$eval('dialog.sheet', d => d.open)), 'dialog closes with Esc');

  // Enquire prefill
  await p.click('#fleet article:nth-of-type(5) button:has-text("Enquire")');
  await p.waitForTimeout(1200);
  assert((await p.inputValue('#f-seating')) === 'coach', 'Enquire pre-selects seating in form');
  const planTop = await p.$eval('#plan', el => el.getBoundingClientRect().top);
  assert(Math.abs(planTop) < 150, 'Enquire scrolls to the form');

  // Destination prefill
  await p.click('#destinations li:nth-child(2) button');
  await p.waitForTimeout(900);
  assert((await p.inputValue('#f-destination')) === 'Rajasthan', 'Plan a trip here pre-fills destination');

  // Validation
  await p.fill('#f-destination', '');
  await p.click('button[type=submit]');
  assert(await p.isVisible('[role=alert]'), 'empty submit shows error summary');
  const focused = await p.evaluate(() => document.activeElement.id);
  assert(focused === 'f-name', 'focus moves to first invalid field');
  assert((await p.$$('[aria-invalid=true]')).length >= 6, 'invalid fields flagged with aria-invalid');

  // Fill & submit
  const d = new Date(); d.setDate(d.getDate() + 10);
  const iso = d.toISOString().slice(0, 10);
  await p.fill('#f-name', 'Test Customer');
  await p.fill('#f-phone', '98250 12345');
  await p.fill('#f-pickup', 'Adajan, Surat');
  await p.fill('#f-destination', 'Dwarka');
  await p.fill('#f-date', iso);
  await p.fill('#f-passengers', '40');
  await p.selectOption('#f-tripType', 'pilgrimage');
  await p.fill('#f-notes', 'AC bus, 3 days');
  await p.click('button[type=submit]');
  await p.waitForTimeout(700);
  const opened = await p.evaluate(() => window.__opened);
  assert(opened.length === 1 && opened[0].startsWith('https://wa.me/917567717570?text='), 'submit opens WhatsApp to business number');
  const msg = decodeURIComponent(opened[0].split('text=')[1]);
  console.log('---- WhatsApp message ----\n' + msg + '\n--------------------------');
  assert(msg.includes('Test Customer') && msg.includes('Dwarka') && msg.includes('Bus / Coach') && msg.includes('Pilgrimage'), 'message contains all details');
  assert(await p.isVisible('[role=status]'), 'success status shown with fallback links');

  // Language switch keeps the section and is remembered
  await p.evaluate(() => { location.hash = '#services'; });
  await p.click('header button[aria-haspopup="true"]');
  await Promise.all([p.waitForNavigation(), p.click('header a[lang="gu"]')]);
  assert(p.url().endsWith('/gu/#services'), 'language switch goes to /gu/ at same section: ' + p.url());
  assert((await p.getAttribute('html', 'lang')) === 'gu-IN', 'html lang is gu-IN');
  assert((await p.textContent('h1')).includes('તમારી સફર'), 'Gujarati headline rendered');
  await p.goto((process.env.BASE || 'http://localhost:3000') + '/', { waitUntil: 'networkidle' });
  await p.waitForTimeout(600);
  assert(p.url().includes('/gu/'), 'returning to / restores saved Gujarati');
  // Gujarati form message labels
  await p.goto((process.env.BASE || 'http://localhost:3000') + '/hi/', { waitUntil: 'networkidle' });
  assert((await p.getAttribute('html', 'lang')) === 'hi-IN' && (await p.textContent('h1')).includes('आपकी यात्रा'), 'Hindi page renders');
  const enLeft = await p.evaluate(() => [...document.querySelectorAll('main h2, main h3, main button, main label')].map(e => e.textContent.trim()).filter(t => /^[A-Za-z ]{12,}$/.test(t)));
  assert(enLeft.length === 0, 'no untranslated English headings/buttons/labels on Hindi page ' + JSON.stringify(enLeft));

  // Reduced motion: everything visible immediately
  const rm = await b.newPage({ reducedMotion: 'reduce', viewport: { width: 390, height: 800 } });
  await rm.goto((process.env.BASE || 'http://localhost:3000') + '/', { waitUntil: 'networkidle' });
  await rm.evaluate(() => localStorage.clear());
  const hiddenRM = await rm.$$eval('[data-reveal], .hero-in', els => els.filter(e => getComputedStyle(e).opacity < 1).length);
  assert(hiddenRM === 0, 'reduced motion: all content visible without animation');
  await rm.evaluate(() => window.scrollTo(0, document.querySelector('#plan').offsetTop));
  await rm.waitForTimeout(500);
  const off = await rm.$eval('[data-road-line]', el => el.style.strokeDashoffset);
  assert(off === '0px' || off === '0', 'reduced motion: signature road fully drawn');

  // Backward scrolling un-draws road
  const p2 = await b.newPage({ viewport: { width: 390, height: 800 } });
  await p2.goto((process.env.BASE || 'http://localhost:3000') + '/', { waitUntil: 'networkidle' });
  await p2.evaluate(() => localStorage.clear());
  await p2.evaluate(() => window.scrollTo(0, document.querySelector('#plan').offsetTop)); await p2.waitForTimeout(900);
  const offEnd = parseFloat(await p2.$eval('[data-road-line]', el => el.style.strokeDashoffset));
  await p2.evaluate(() => window.scrollTo(0, document.querySelector('#fleet').offsetTop)); await p2.waitForTimeout(900);
  const offBack = parseFloat(await p2.$eval('[data-road-line]', el => el.style.strokeDashoffset));
  assert(offBack > offEnd + 500, `road responds to backward scroll (end ${offEnd.toFixed(0)} → back ${offBack.toFixed(0)})`);
  const revealedStill = await p2.$$eval('#plan [data-reveal]', els => els.every(e => getComputedStyle(e).opacity == 1));
  assert(revealedStill, 'revealed sections stay visible when scrolling back (no restart)');

  assert(errs.length === 0, 'no page errors ' + JSON.stringify(errs));
  await b.close();
})().catch(e => { console.error(e.message); process.exit(1); });
