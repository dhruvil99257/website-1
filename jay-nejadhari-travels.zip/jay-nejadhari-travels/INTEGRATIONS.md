# INTEGRATIONS — third-party services

> Reads PRD.md, ARCHITECTURE.md, API.md.

## v1 integrations (live)
### 1. WhatsApp (click-to-chat)
| | |
|---|---|
| Why | Primary enquiry channel; familiar to every customer in India |
| Env vars | None — number in `src/config/business.ts → whatsappNumber` |
| SDK / package | None — `https://wa.me/<number>?text=<message>` deep link |
| Wrapper | `src/lib/whatsapp.ts` (`waLink`, `buildInquiryMessage`) — components never build URLs themselves |
| Errors / fallback | Pop-up blocked → same-tab navigation; after sending, the form shows "Open WhatsApp again" and "Call instead" |
| Cost / limits | Free; no API rate limits (the visitor sends the message) |
| Test | `npm test` (message builder) and `tests/e2e.cjs` (mocks `window.open`, never messages the real number) |

### 2. Phone (tel:)
Wrapper `telLink()` in `src/lib/whatsapp.ts`; number in `business.phoneE164`. Free, works on every phone; desktop opens the default calling app.

**Swapping later:** because every link comes from these two helpers and one config file, changing the number or moving to the WhatsApp Business API touches only `lib/whatsapp.ts` and `config/business.ts`.

## Not used in v1 (and why)
| Service | Status | Reason |
|---|---|---|
| Payments (Stripe / Razorpay) | Not needed | Pricing is per-km and negotiated; no online payment (PRD non-goal) |
| AI (OpenAI / Anthropic) | Not needed | No AI features in the MVP |
| File storage (S3 / Supabase Storage) | Not needed | Images are static files in `public/` |
| Email | Not needed | Owner did not supply an email; WhatsApp/phone cover enquiries |
| Analytics | Not added | No consent banner/privacy policy yet; add privacy-friendly analytics later if wanted |

## Future integration plan (V2, only if the owner wants it)
### Enquiry log (Google Sheets or Supabase)
- Env: `SHEETS_WEBHOOK_URL` *or* `SUPABASE_URL`, `SUPABASE_ANON_KEY` (server only).
- Wrapper: `src/lib/inquiryLog.ts` called from a serverless function `POST /api/v1/inquiries` — never from the browser directly.
- Retries: 2 retries with backoff; idempotency key = hash(phone + date + destination + minute).
- Fallback: if logging fails, WhatsApp still opens (logging must never block the enquiry).
- Test: Supabase local / a test Sheet.
- Note: needs moving off pure static export (e.g. Vercel/Netlify functions).

### Google Business Profile / Reviews
- Link the profile in `business.socials` (`network: 'google'`); copy real reviews into `config/reviews.ts` with permission.

### Analytics (privacy-friendly)
- Plausible or Cloudflare Web Analytics (cookie-less) — one script tag, track `tel:` and `wa.me` clicks as goals.
