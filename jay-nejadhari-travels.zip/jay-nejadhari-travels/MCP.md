# MCP — connecting AI assistants to tools for this project

> Model Context Protocol (MCP) servers let an AI coding assistant read files, run a browser or open GitHub issues. This site has no database or backend, so only a few servers are useful.

## 1. Useful servers
| Server | Why for this project | Default access |
|---|---|---|
| **Filesystem** | Read/edit the repo, especially `src/config` and `src/i18n` | Project folder only |
| **Playwright (browser)** | Check layouts at 320–430 px, test WhatsApp/Call links, language switch, screenshots | Localhost only |
| **GitHub** (if the repo is on GitHub) | Open issues/PRs for content changes | Read-only by default |
| **Fetch / docs** | Look up Next.js, Tailwind, GSAP docs | Read-only |
Not needed: database servers (no DB), payment servers (no payments).

## 2. Configuration snippets
Claude Desktop / Claude Code style `mcp.json` (adjust paths):
```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "/path/to/jay-nejadhari-travels"]
    },
    "playwright": {
      "command": "npx",
      "args": ["-y", "@playwright/mcp@latest", "--isolated"]
    },
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": { "GITHUB_PERSONAL_ACCESS_TOKEN": "${GITHUB_TOKEN}" }
    }
  }
}
```
Windows paths use double backslashes, e.g. `"C:\\\\sites\\\\jay-nejadhari-travels"`.

## 3. Allowed vs blocked tools
| Allowed | Blocked / ask first |
|---|---|
| Read any project file | Writing outside the project folder |
| Edit `src/**`, `*.md`, `public/**` | Deleting files or folders |
| Browser on `http://localhost:*` | Browsing logged-in sites, submitting real WhatsApp messages |
| GitHub: read issues/PRs | GitHub: push to main, delete branches, change settings |

## 4. Safety rules
- **Read-only by default**; the assistant must confirm before any destructive action (delete, overwrite many files, force-push).
- Follow AGENTS.md: never invent business facts, never add libraries without asking.
- Never send test enquiries to the real WhatsApp number — tests mock `window.open` (see `tests/e2e.cjs`).

## 5. Test each connection
- Filesystem: ask "list files in src/config" → should show business.ts, fleet.ts…
- Playwright: run `npm run build && npm start`, then ask "open http://localhost:3000 at 375px width and screenshot".
- GitHub: ask "list open issues" (needs `GITHUB_TOKEN` env var set in your shell).

## 6. Troubleshooting
| Problem | Fix |
|---|---|
| `npx` not found | Install Node 22+, restart the AI app. |
| Server shows as disconnected | Check JSON syntax (no trailing commas) and absolute paths; restart the app. |
| Filesystem "access denied" | The path in `args` must contain the project; use the absolute path. |
| Playwright can't launch browser | Run `npx playwright install chromium` once. |
| GitHub 401 | Token missing/expired; set `GITHUB_TOKEN` in your environment (never paste real keys into this file). |
