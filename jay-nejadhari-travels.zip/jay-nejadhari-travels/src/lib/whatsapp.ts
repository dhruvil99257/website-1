/**
 * The only outbound "API" of the site (see API.md). Pure functions, no imports,
 * so they can be unit-tested directly with node:test.
 */

export function telLink(phoneE164: string): string {
  return `tel:${phoneE164}`;
}

export function waLink(whatsappNumber: string, message?: string): string {
  const base = `https://wa.me/${whatsappNumber.replace(/[^\d]/g, '')}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}

export interface MessageLabels {
  heading: string;
  name: string;
  phone: string;
  pickup: string;
  destination: string;
  date: string;
  passengers: string;
  seating: string;
  tripType: string;
  notes: string;
  footer: string;
}

export interface MessageValues {
  name: string;
  phone: string;
  pickup: string;
  destination: string;
  date: string; // already formatted for display
  passengers: string;
  seating: string; // already translated label
  tripType: string; // already translated label
  notes: string;
}

/** Builds the formatted WhatsApp enquiry (WhatsApp renders *bold*). Empty optional lines are skipped. */
export function buildInquiryMessage(
  businessName: string,
  labels: MessageLabels,
  v: MessageValues,
  langCode: string,
): string {
  const line = (emoji: string, label: string, value: string) =>
    value.trim() ? `${emoji} ${label}: ${value.trim()}` : null;

  return [
    `*${labels.heading}* 🚐`,
    businessName,
    '',
    line('👤', labels.name, v.name),
    line('📞', labels.phone, v.phone),
    line('📍', labels.pickup, v.pickup),
    line('🏁', labels.destination, v.destination),
    line('📅', labels.date, v.date),
    line('👥', labels.passengers, v.passengers),
    line('💺', labels.seating, v.seating),
    line('🧭', labels.tripType, v.tripType),
    line('📝', labels.notes, v.notes),
    '',
    `_${labels.footer} (${langCode.toUpperCase()})_`,
  ]
    .filter((l) => l !== null)
    .join('\n');
}

/** Formats yyyy-mm-dd as e.g. "24 Dec 2026" in the chosen language. */
export function formatTravelDate(iso: string, bcp47: string): string {
  const [y, m, d] = iso.split('-').map(Number);
  if (!y || !m || !d) return iso;
  const date = new Date(Date.UTC(y, m - 1, d));
  return new Intl.DateTimeFormat(bcp47, { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }).format(date);
}
