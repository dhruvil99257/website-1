import type { Metadata, Viewport } from 'next';
import { business, siteUrl } from '@/config/business';
import { getDictionary, localePath, type Locale } from '@/i18n';

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  themeColor: '#173D5B',
};

export function buildMetadata(lang: Locale): Metadata {
  const t = getDictionary(lang);
  const url = siteUrl + localePath[lang];
  return {
    metadataBase: new URL(siteUrl),
    title: t.meta.title,
    description: t.meta.description,
    keywords: t.meta.keywords,
    alternates: {
      canonical: url,
      languages: {
        'en-IN': siteUrl + localePath.en,
        'gu-IN': siteUrl + localePath.gu,
        'hi-IN': siteUrl + localePath.hi,
        'x-default': siteUrl + localePath.en,
      },
    },
    openGraph: {
      type: 'website',
      url,
      siteName: business.name,
      title: t.meta.title,
      description: t.meta.description,
      locale: lang === 'en' ? 'en_IN' : lang === 'gu' ? 'gu_IN' : 'hi_IN',
      images: [{ url: '/og-image.png', width: 1200, height: 630, alt: business.name }],
    },
    twitter: { card: 'summary_large_image', title: t.meta.title, description: t.meta.description, images: ['/og-image.png'] },
    formatDetection: { telephone: true },
    robots: { index: true, follow: true },
  };
}
