/**
 * Convert latitude/longitude to the India map's SVG coordinates (viewBox 0 0 612 696).
 * The map source uses a Mercator projection; constants were calibrated against
 * state borders (Gujarat west edge = 68.1°E, Arunachal east edge = 97.4°E).
 */
const X_PER_DEG = 20.88;
const LON0 = 68.1;
const Y_SCALE = 1195;
const Y_REF = 302.9; // y of 24.7°N (Gujarat north edge)
const M_REF = mercator(24.7);

function mercator(lat: number) {
  return Math.log(Math.tan(Math.PI / 4 + (lat * Math.PI) / 360));
}

export function project(lat: number, lon: number): { x: number; y: number } {
  return {
    x: Math.round((lon - LON0) * X_PER_DEG * 10) / 10,
    y: Math.round((Y_REF + (M_REF - mercator(lat)) * Y_SCALE) * 10) / 10,
  };
}

/** A gentle curved route (quadratic Bézier) between two map points. */
export function routePath(a: { x: number; y: number }, b: { x: number; y: number }, bend = 0.22) {
  const mx = (a.x + b.x) / 2;
  const my = (a.y + b.y) / 2;
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  // perpendicular offset
  const cx = mx - dy * bend;
  const cy = my + dx * bend;
  return `M${a.x} ${a.y}Q${Math.round(cx)} ${Math.round(cy)} ${b.x} ${b.y}`;
}
