/**
 * Tiny event bus: "Enquire" buttons anywhere on the page pre-fill the inquiry form
 * and scroll to it. No global store needed (ARCHITECTURE.md §4).
 */
export interface PrefillDetail {
  seating?: string;
  destination?: string;
  tripType?: string;
}

export const PREFILL_EVENT = 'jnt:prefill';

export function requestPrefill(detail: PrefillDetail) {
  window.dispatchEvent(new CustomEvent<PrefillDetail>(PREFILL_EVENT, { detail }));
  const target = document.getElementById('plan');
  if (target) {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    target.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
    // Move focus to the first empty field after scrolling, for keyboard & screen-reader users.
    window.setTimeout(() => {
      const first = target.querySelector<HTMLInputElement>('input:not([type=hidden])');
      first?.focus({ preventScroll: true });
    }, reduce ? 0 : 650);
  }
}
