/**
 * Inquiry validation — pure functions (no imports) so they can be unit-tested with node:test.
 * Error format (API.md): { field, code }.
 */
export interface Inquiry {
  name: string;
  phone: string;
  pickup: string;
  destination: string;
  date: string; // yyyy-mm-dd
  passengers: string;
  seating: string; // fleet id or 'any'
  tripType: string; // service id
  notes: string;
}

export type ErrorCode = 'required' | 'invalidPhone' | 'pastDate' | 'passengersRange' | 'tooLong' | 'tooShort';
export interface FieldError {
  field: keyof Inquiry;
  code: ErrorCode;
}

export const emptyInquiry: Inquiry = {
  name: '',
  phone: '',
  pickup: '',
  destination: '',
  date: '',
  passengers: '',
  seating: 'any',
  tripType: '',
  notes: '',
};

/** Accepts 98xxxxxxxx, +91 98xxx xxxxx, 091-98xxxxxxxx, 0 98xxxxxxxx. Returns 10 digits or null. */
export function normalizeIndianMobile(input: string): string | null {
  let d = input.replace(/[^\d]/g, '');
  if (d.length === 12 && d.startsWith('91')) d = d.slice(2);
  else if (d.length === 13 && d.startsWith('091')) d = d.slice(3);
  else if (d.length === 11 && d.startsWith('0')) d = d.slice(1);
  return /^[6-9]\d{9}$/.test(d) ? d : null;
}

/** Today's date as yyyy-mm-dd in the visitor's local time zone. */
export function todayISO(now: Date = new Date()): string {
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function text(field: keyof Inquiry, value: string, max: number, errors: FieldError[], required = true) {
  const v = value.trim();
  if (!v) {
    if (required) errors.push({ field, code: 'required' });
    return;
  }
  if (v.length < 2 && required) errors.push({ field, code: 'tooShort' });
  else if (v.length > max) errors.push({ field, code: 'tooLong' });
}

export function validateInquiry(q: Inquiry, now: Date = new Date()): FieldError[] {
  const errors: FieldError[] = [];
  text('name', q.name, 80, errors);

  if (!q.phone.trim()) errors.push({ field: 'phone', code: 'required' });
  else if (!normalizeIndianMobile(q.phone)) errors.push({ field: 'phone', code: 'invalidPhone' });

  text('pickup', q.pickup, 120, errors);
  text('destination', q.destination, 120, errors);

  if (!q.date) errors.push({ field: 'date', code: 'required' });
  else if (q.date < todayISO(now)) errors.push({ field: 'date', code: 'pastDate' });

  if (!q.passengers.trim()) errors.push({ field: 'passengers', code: 'required' });
  else {
    const n = Number(q.passengers);
    if (!Number.isInteger(n) || n < 1 || n > 500) errors.push({ field: 'passengers', code: 'passengersRange' });
  }

  if (!q.tripType) errors.push({ field: 'tripType', code: 'required' });
  if (q.notes.trim().length > 500) errors.push({ field: 'notes', code: 'tooLong' });
  return errors;
}
