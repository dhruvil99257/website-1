/**
 * DESTINATIONS — gallery cards + map pins. Text lives in src/i18n → destinations.
 * Coordinates are real latitude/longitude; the map converts them automatically.
 * These are example destinations the business can travel to (All India coverage),
 * not a list of packaged tours.
 */
export const destinationIds = [
  'gujarat',
  'rajasthan',
  'goa',
  'kashmir',
  'maharashtra',
  'kerala',
  'himachal',
  'uttarakhand',
] as const;

export type DestinationId = (typeof destinationIds)[number];

export const HOME_BASE = { lat: 21.17, lon: 72.83 }; // Surat

/** One representative map point per destination card. */
export const destinationPins: Record<DestinationId, { lat: number; lon: number }> = {
  gujarat: { lat: 22.24, lon: 68.97 }, // Dwarka
  rajasthan: { lat: 26.91, lon: 75.79 }, // Jaipur
  goa: { lat: 15.49, lon: 73.83 }, // Panaji
  kashmir: { lat: 34.08, lon: 74.8 }, // Srinagar
  maharashtra: { lat: 19.77, lon: 74.48 }, // Shirdi
  kerala: { lat: 10.09, lon: 77.06 }, // Munnar
  himachal: { lat: 32.24, lon: 77.19 }, // Manali
  uttarakhand: { lat: 30.09, lon: 78.27 }, // Rishikesh
};

/** Extra cities shown as small dots for "All India coverage" (no routes). */
export const coverageDots: { lat: number; lon: number }[] = [
  { lat: 28.61, lon: 77.21 }, // Delhi
  { lat: 25.32, lon: 82.97 }, // Varanasi
  { lat: 23.18, lon: 75.78 }, // Ujjain
  { lat: 22.57, lon: 88.36 }, // Kolkata
  { lat: 12.97, lon: 77.59 }, // Bengaluru
  { lat: 13.08, lon: 80.27 }, // Chennai
  { lat: 17.39, lon: 78.49 }, // Hyderabad
  { lat: 26.14, lon: 91.74 }, // Guwahati
  { lat: 21.15, lon: 79.09 }, // Nagpur
  { lat: 20.89, lon: 70.4 }, // Somnath
  { lat: 24.58, lon: 73.71 }, // Udaipur
  { lat: 18.52, lon: 73.86 }, // Pune
];
