/**
 * CUSTOMER REVIEWS — add REAL reviews only, with the customer's permission.
 * Never invent reviews or ratings. While this list is empty, the site shows a
 * friendly "share your experience" message instead.
 *
 * Example (delete the comment markers to use):
 * {
 *   id: 'r1',
 *   name: 'Customer name',
 *   place: 'Surat',
 *   text: 'Exactly what the customer wrote…',
 *   lang: 'gu',
 *   date: '2026-12-01',
 *   source: 'Google',
 * },
 */
export interface Review {
  id: string;
  name: string;
  place?: string;
  text: string;
  lang: 'en' | 'gu' | 'hi';
  date: string;
  source: 'Google' | 'WhatsApp' | 'In person' | string;
}

export const reviews: Review[] = [];
