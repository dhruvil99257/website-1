/** SERVICES — the 7 services from the owner's brief. Text lives in src/i18n → services.items. */
export const serviceIds = [
  'local',
  'outstation',
  'oneway',
  'roundtrip',
  'wedding',
  'corporate',
  'pilgrimage',
] as const;

export type ServiceId = (typeof serviceIds)[number];

/** Accent colour band behind each service illustration (DESIGN.md palette only). */
export const serviceAccent: Record<ServiceId, string> = {
  local: '#FCE9CC',
  outstation: '#DCEBE1',
  oneway: '#E3ECF3',
  roundtrip: '#FCE9CC',
  wedding: '#FBE1D3',
  corporate: '#E3ECF3',
  pilgrimage: '#FCE9CC',
};
