/** Section ids used by header, mobile menu and footer navigation (order = page order). */
export const NAV_SECTIONS = ['india', 'fleet', 'services', 'destinations', 'why', 'plan', 'contact'] as const;
