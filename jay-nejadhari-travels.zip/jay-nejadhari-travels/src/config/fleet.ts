/**
 * FLEET CATALOGUE — editable.
 *
 * The owner confirmed the fleet ranges from 4 to 56 seats but did not list exact
 * categories or models. These five categories are an EDITABLE STARTING SET — change
 * seat numbers, add or remove categories to match the real fleet. Names and
 * descriptions for each `id` live in src/i18n/{en,gu,hi}.ts → fleet.items.
 *
 * Images: the cards use illustrations (labelled "Illustrative image" on the site).
 * When you have real photos, put them in /public/images/fleet/ and set `image`
 * (WebP recommended, 1200×750). Then set `isIllustrative: false`.
 */
export type VehicleArt = 'sedan' | 'suv' | 'traveller' | 'minibus' | 'coach';

export interface Vehicle {
  id: string;
  /** Seat range shown on the card. Use the same number twice for a fixed size. */
  seatsMin: number;
  seatsMax: number;
  art: VehicleArt;
  image?: string;
  isIllustrative: boolean;
  active: boolean;
}

export const fleet: Vehicle[] = [
  { id: 'car', seatsMin: 4, seatsMax: 4, art: 'sedan', isIllustrative: true, active: true },
  { id: 'suv', seatsMin: 6, seatsMax: 7, art: 'suv', isIllustrative: true, active: true },
  { id: 'traveller', seatsMin: 12, seatsMax: 20, art: 'traveller', isIllustrative: true, active: true },
  { id: 'minibus', seatsMin: 21, seatsMax: 35, art: 'minibus', isIllustrative: true, active: true },
  { id: 'coach', seatsMin: 36, seatsMax: 56, art: 'coach', isIllustrative: true, active: true },
];

export const activeFleet = fleet.filter((v) => v.active);

export function seatLabel(v: Pick<Vehicle, 'seatsMin' | 'seatsMax'>): string {
  return v.seatsMin === v.seatsMax ? `${v.seatsMin}` : `${v.seatsMin}–${v.seatsMax}`;
}
