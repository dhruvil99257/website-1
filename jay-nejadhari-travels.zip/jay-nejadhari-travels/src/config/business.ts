/**
 * BUSINESS DETAILS — the single place to edit contact information.
 * Only verified facts go here. Fields marked PLACEHOLDER are hidden on the site
 * until you fill them in (see PRD.md → Open questions).
 */
export const business = {
  name: 'Jay Nejadhari Tours and Travels',
  shortName: 'Jay Nejadhari',
  city: 'Surat',
  state: 'Gujarat',
  country: 'India',
  countryCode: 'IN',

  /** Shown to visitors */
  phoneDisplay: '+91 75677 17570',
  /** Used in tel: links (E.164, no spaces) */
  phoneE164: '+917567717570',
  /** Used in wa.me links (country code + number, digits only) */
  whatsappNumber: '917567717570',

  /** PLACEHOLDER — full street address. Leave '' to show only "Surat, Gujarat". */
  addressLine: '',
  /** PLACEHOLDER — Google Maps share link for the office. Leave '' to hide. */
  mapsUrl: '',
  /** PLACEHOLDER — business email. Leave '' to hide. */
  email: '',

  /**
   * PLACEHOLDER — logo. No logo file was supplied, so the header shows the
   * business name as text. Put your logo in /public/brand/ (e.g. logo.png or logo.svg)
   * and set the path here, e.g. '/brand/logo.png'.
   */
  logoSrc: '' as string,
  /** Natural size of your logo file (prevents layout shift). */
  logoWidth: 160,
  logoHeight: 48,

  /**
   * PLACEHOLDER — social accounts. Add real links only, e.g.
   * { network: 'instagram', url: 'https://instagram.com/yourpage' }
   * Supported: instagram, facebook, youtube, google.
   */
  socials: [] as { network: 'instagram' | 'facebook' | 'youtube' | 'google'; url: string }[],

  /** Verified business facts (from the owner's brief) */
  facts: {
    ownFleet: true,
    seatsMin: 4,
    seatsMax: 56,
    coverage: 'All India',
    pricing: 'Per kilometre, final rate by discussion',
  },
} as const;

/** Canonical site URL — set NEXT_PUBLIC_SITE_URL in .env.local before deploying. */
export const siteUrl = (process.env.NEXT_PUBLIC_SITE_URL || 'https://www.example.com').replace(/\/$/, '');
