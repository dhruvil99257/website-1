import type { VehicleArt as ArtKey } from '@/config/fleet';

/**
 * Representative side-view vehicle illustrations (NOT actual fleet photos —
 * cards are labelled "Illustrative image"). viewBox 320×200.
 */
const GROUND = 160;

function Wheel({ cx }: { cx: number }) {
  return (
    <g>
      <circle cx={cx} cy={GROUND - 4} r="17" fill="#242A30" />
      <circle cx={cx} cy={GROUND - 4} r="8" fill="#C9D3DC" />
      <circle cx={cx} cy={GROUND - 4} r="3" fill="#242A30" />
    </g>
  );
}

interface BoxProps {
  x: number;
  len: number;
  h: number;
  nose: number;
  body: string;
  stripe: string;
  windows: number;
  wheels: number[];
  roofRack?: boolean;
}

/** Generic van / bus side profile facing right */
function BoxVehicle({ x, len, h, nose, body, stripe, windows, wheels, roofRack }: BoxProps) {
  const top = GROUND - 12 - h;
  const right = x + len;
  const winTop = top + 10;
  const winH = Math.round(h * 0.34);
  const winEnd = right - nose - 8;
  const gap = 5;
  const winW = (winEnd - (x + 10) - gap * (windows - 1)) / windows;
  return (
    <g>
      {roofRack && <rect x={x + 20} y={top - 8} width={len * 0.45} height="8" rx="2" fill="#0F2B41" />}
      <path
        d={`M${x} ${GROUND - 12}V${top + 12}Q${x} ${top} ${x + 12} ${top}H${right - nose}Q${right - nose * 0.4} ${top} ${right - 2} ${top + nose * 1.1}Q${right} ${top + nose * 1.3} ${right} ${top + nose * 1.6}V${GROUND - 12}z`}
        fill={body}
      />
      {Array.from({ length: windows }).map((_, i) => (
        <rect key={i} x={x + 10 + i * (winW + gap)} y={winTop} width={winW} height={winH} rx="4" fill="#9FC3DA" />
      ))}
      <path d={`M${winEnd + 6} ${winTop}H${right - nose * 0.55}L${right - 4} ${winTop + winH}H${winEnd + 6}z`} fill="#7EAAC6" />
      <rect x={x} y={winTop + winH + 12} width={len} height="8" fill={stripe} />
      <rect x={x} y={winTop + winH + 22} width={len} height="4" fill="#4D8865" />
      <rect x={right - 10} y={GROUND - 30} width="10" height="8" rx="2" fill="#FFD27A" />
      <rect x={x} y={GROUND - 16} width={len} height="6" rx="3" fill="#0F2B41" />
      {wheels.map((w) => (
        <Wheel key={w} cx={x + w} />
      ))}
    </g>
  );
}

function Sedan() {
  return (
    <g>
      <path
        d="M40 148V124q2-14 20-18l42-6 30-24q8-6 20-6h54q12 0 22 8l28 22 26 4q14 4 14 18v26z"
        fill="#F7F5EF"
        stroke="#173D5B"
        strokeWidth="2.5"
      />
      <path d="M138 80l12-6h28v28h-60z" fill="#9FC3DA" />
      <path d="M186 74h22q8 0 14 6l20 22h-56z" fill="#9FC3DA" />
      <rect x="40" y="118" width="256" height="6" fill="#F3A43B" />
      <rect x="286" y="126" width="10" height="7" rx="2" fill="#FFD27A" />
      <rect x="40" y="140" width="256" height="8" rx="3" fill="#173D5B" />
      <Wheel cx={96} />
      <Wheel cx={246} />
    </g>
  );
}

export default function VehicleArt({ art, className = '' }: { art: ArtKey; className?: string }) {
  return (
    <svg viewBox="0 0 320 200" className={className} aria-hidden="true" preserveAspectRatio="xMidYMid slice">
      {/* backdrop */}
      <rect width="320" height="200" fill="#FBEFD9" />
      <circle cx="262" cy="52" r="26" fill="#F3A43B" opacity=".55" />
      <path d="M0 132c50-18 90-22 140-10s110 10 180-14v92H0z" fill="#B9CFC2" />
      <rect y={GROUND + 10} width="320" height="40" fill="#5B6670" />
      <path d={`M0 ${GROUND + 28}H320`} stroke="#F3A43B" strokeWidth="4" strokeDasharray="20 18" />
      <ellipse cx="160" cy={GROUND + 12} rx="140" ry="6" fill="#242A30" opacity=".25" />

      {art === 'sedan' && <Sedan />}
      {art === 'suv' && <BoxVehicle x={46} len={232} h={70} nose={46} body="#173D5B" stripe="#F3A43B" windows={3} wheels={[50, 186]} roofRack />}
      {art === 'traveller' && <BoxVehicle x={24} len={276} h={92} nose={40} body="#F7F5EF" stripe="#173D5B" windows={5} wheels={[52, 222]} />}
      {art === 'minibus' && <BoxVehicle x={14} len={294} h={98} nose={30} body="#4D8865" stripe="#F3A43B" windows={6} wheels={[54, 238]} />}
      {art === 'coach' && <BoxVehicle x={6} len={308} h={108} nose={20} body="#173D5B" stripe="#F3A43B" windows={7} wheels={[56, 210, 252]} />}
    </svg>
  );
}
