'use client';

import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

/**
 * SIGNATURE ANIMATION — an illustrated road that runs from the hero down through every
 * section and ends at the inquiry form. It is drawn by scroll progress (the road's tip
 * follows a point ~60% down the viewport), so scrolling back "un-draws" it naturally.
 *
 * - Never pins, snaps or hijacks scrolling: it only reads scroll position.
 * - The road sits in the side gutters and crosses sides only in the empty padding
 *   between sections, so it never runs behind text.
 * - Reduced motion: drawn completely, no moving vehicle.
 */

interface Geometry {
  w: number;
  h: number;
  d: string;
  end: { x: number; y: number };
}

function buildGeometry(main: HTMLElement): Geometry | null {
  const sections = Array.from(main.querySelectorAll<HTMLElement>('[data-road-stop]'));
  const form = main.querySelector<HTMLElement>('[data-road-end]');
  if (sections.length < 2 || !form) return null;

  const mainTop = main.getBoundingClientRect().top + window.scrollY;
  const w = main.clientWidth;
  const h = main.scrollHeight;
  const container = Math.min(w, 1200);
  const margin = (w - container) / 2;
  const pad = w < 480 ? 16 : 24;
  // Road centre: middle of the outer margin on wide screens, middle of the padding on phones
  const inset = margin > 48 ? margin / 2 : margin + pad / 2;
  const left = Math.round(inset);
  const right = Math.round(w - inset);

  const top = (el: HTMLElement) => Math.round(el.getBoundingClientRect().top + window.scrollY - mainTop);
  const t0 = top(sections[0]);
  const formTop = top(form);

  let side = left;
  let d = `M${Math.round(w / 2)} ${t0 - 2}C${Math.round(w / 2)} ${t0 + 34} ${side} ${t0 + 16} ${side} ${t0 + 56}`;
  for (let i = 1; i < sections.length; i++) {
    const ti = top(sections[i]);
    const other = side === left ? right : left;
    d += `V${ti - 46}C${side} ${ti - 4} ${other} ${ti + 4} ${other} ${ti + 46}`;
    side = other;
  }
  const endY = formTop + 28;
  d += `V${endY}`;
  return { w, h, d, end: { x: side, y: endY } };
}

export default function SignatureRoad() {
  const svgRef = useRef<SVGSVGElement>(null);
  const [geo, setGeo] = useState<Geometry | null>(null);

  // Build / rebuild geometry whenever the page layout changes size
  useEffect(() => {
    const main = svgRef.current?.parentElement;
    if (!main) return;
    let timer = 0;
    const rebuild = () => {
      window.clearTimeout(timer);
      timer = window.setTimeout(() => setGeo(buildGeometry(main)), 120);
    };
    rebuild();
    const ro = new ResizeObserver(rebuild);
    ro.observe(main);
    document.fonts?.ready.then(rebuild).catch(() => {});
    return () => {
      ro.disconnect();
      window.clearTimeout(timer);
    };
  }, []);

  // Drive the drawing from scroll position
  useEffect(() => {
    const svg = svgRef.current;
    if (!svg || !geo) return;
    const paths = Array.from(svg.querySelectorAll<SVGPathElement>('[data-road-line]'));
    const bus = svg.querySelector<SVGGElement>('[data-road-bus]');
    const pin = svg.querySelector<SVGGElement>('[data-road-pin]');
    const main = svg.parentElement!;
    const len = paths[0].getTotalLength();
    paths.forEach((p) => {
      p.style.strokeDasharray = `${len} ${len}`;
      p.style.strokeDashoffset = `${len}`;
    });

    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) {
      paths.forEach((p) => (p.style.strokeDashoffset = '0'));
      if (bus) bus.style.display = 'none';
      if (pin) pin.style.opacity = '1';
      return;
    }

    // Lookup table: path length → y (the path only ever moves downwards, so y is monotonic)
    const samples = 240;
    const table: { l: number; y: number }[] = [];
    for (let i = 0; i <= samples; i++) {
      const l = (len * i) / samples;
      table.push({ l, y: paths[0].getPointAtLength(l).y });
    }
    const lengthAtY = (y: number) => {
      if (y <= table[0].y) return 0;
      if (y >= table[samples].y) return len;
      let lo = 0;
      let hi = samples;
      while (hi - lo > 1) {
        const mid = (lo + hi) >> 1;
        if (table[mid].y < y) lo = mid;
        else hi = mid;
      }
      const a = table[lo];
      const b = table[hi];
      return a.l + ((y - a.y) / (b.y - a.y || 1)) * (b.l - a.l);
    };

    const state = { drawn: 0 };
    const render = () => {
      const off = len - state.drawn;
      paths.forEach((p) => (p.style.strokeDashoffset = `${off}`));
      if (bus) {
        const l = Math.max(1, state.drawn);
        const p = paths[0].getPointAtLength(l);
        const q = paths[0].getPointAtLength(Math.max(0, l - 2));
        const angle = (Math.atan2(p.y - q.y, p.x - q.x) * 180) / Math.PI;
        bus.setAttribute('transform', `translate(${p.x.toFixed(1)} ${p.y.toFixed(1)}) rotate(${angle.toFixed(1)})`);
        bus.style.opacity = state.drawn > 4 && state.drawn < len - 2 ? '1' : '0';
      }
      if (pin) pin.style.opacity = state.drawn >= len - 4 ? '1' : '0';
    };

    const update = () => {
      const mainTop = main.getBoundingClientRect().top + window.scrollY;
      const target = lengthAtY(window.scrollY + window.innerHeight * 0.6 - mainTop);
      gsap.to(state, { drawn: target, duration: 0.35, ease: 'power2.out', overwrite: true, onUpdate: render });
    };

    const st = ScrollTrigger.create({ trigger: main, start: 'top bottom', end: 'bottom top', onUpdate: update, onRefresh: update });
    update();
    return () => {
      st.kill();
      gsap.killTweensOf(state);
    };
  }, [geo]);

  return (
    <svg
      ref={svgRef}
      aria-hidden="true"
      className="pointer-events-none absolute left-0 top-0 z-[1] print:hidden"
      width={geo?.w ?? 0}
      height={geo?.h ?? 0}
      viewBox={geo ? `0 0 ${geo.w} ${geo.h}` : undefined}
      style={{ overflow: 'visible' }}
    >
      {geo && (
        <>
          <g fill="none" strokeLinecap="round" strokeLinejoin="round">
            <path data-road-line d={geo.d} stroke="#F7F5EF" strokeOpacity=".9" strokeWidth={geo.w < 768 ? 9 : 16} />
            <path data-road-line d={geo.d} stroke="#3A4148" strokeWidth={geo.w < 768 ? 6 : 12} />
            <path data-road-line d={geo.d} stroke="#F3A43B" strokeWidth={geo.w < 768 ? 1.5 : 2.5} />
          </g>
          {/* top-down mini bus that drives at the tip of the road */}
          <g data-road-bus style={{ opacity: 0, transition: 'opacity .2s' }}>
            <g transform={geo.w < 768 ? 'scale(.62)' : undefined}>
              <rect x="-15" y="-8" width="30" height="16" rx="4" fill="#173D5B" stroke="#F7F5EF" strokeWidth="1.5" />
              <rect x="7" y="-6" width="6" height="12" rx="2" fill="#9FC3DA" />
              <rect x="-11" y="-3" width="15" height="6" rx="1.5" fill="#F3A43B" />
            </g>
          </g>
          {/* destination pin at the form */}
          <g data-road-pin transform={`translate(${geo.end.x} ${geo.end.y})`} style={{ opacity: 0, transition: 'opacity .3s' }}>
            <g transform={geo.w < 768 ? 'scale(.7)' : undefined}>
              <path d="M0 2c-8-9-12-14-12-20a12 12 0 0 1 24 0c0 6-4 11-12 20z" fill="#F3A43B" stroke="#173D5B" strokeWidth="2" />
              <circle cy="-18" r="4.5" fill="#173D5B" />
            </g>
          </g>
        </>
      )}
    </svg>
  );
}
