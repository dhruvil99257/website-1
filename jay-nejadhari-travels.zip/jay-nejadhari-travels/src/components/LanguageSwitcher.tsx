'use client';

import { useEffect, useId, useRef, useState } from 'react';
import { locales, localePath, type Locale } from '@/i18n/types';
import { ChevronDownIcon, GlobeIcon } from './Icons';

export const LANG_KEY = 'jnt-lang';

const native: Record<Locale, { short: string; name: string }> = {
  en: { short: 'EN', name: 'English' },
  gu: { short: 'ગુ', name: 'ગુજરાતી' },
  hi: { short: 'हि', name: 'हिन्दी' },
};

/** Saves the choice and opens the same section in the chosen language. */
export function switchLanguage(to: Locale) {
  try {
    localStorage.setItem(LANG_KEY, to);
  } catch {
    /* storage blocked — still navigate */
  }
  const hash = window.location.hash || '';
  window.location.href = localePath[to] + hash;
}

/** Compact dropdown (header) */
export function LanguageMenu({ lang, label, onDark }: { lang: Locale; label: string; onDark: boolean }) {
  const [open, setOpen] = useState(false);
  const id = useId();
  const wrap = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent | KeyboardEvent) => {
      if (e instanceof KeyboardEvent ? e.key === 'Escape' : !wrap.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('click', close);
    document.addEventListener('keydown', close);
    return () => {
      document.removeEventListener('click', close);
      document.removeEventListener('keydown', close);
    };
  }, [open]);

  return (
    <div ref={wrap} className="relative">
      <button
        type="button"
        aria-haspopup="true"
        aria-expanded={open}
        aria-controls={id}
        onClick={() => setOpen((o) => !o)}
        className={`flex min-h-[44px] items-center gap-1.5 rounded-full border-2 px-3 text-sm font-bold transition-colors ${
          onDark ? 'border-white/60 text-white hover:bg-white/10' : 'border-navy/30 text-navy hover:bg-navy/5'
        }`}
      >
        <GlobeIcon size={18} />
        <span className="sr-only">{label}: </span>
        <span className="native-name">{native[lang].short}</span>
        <ChevronDownIcon size={16} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <ul id={id} className="absolute right-0 top-[calc(100%+8px)] z-50 w-44 overflow-hidden rounded-md bg-white py-1 shadow-lift" role="list">
          {locales.map((l) => (
            <li key={l}>
              <a
                href={localePath[l]}
                lang={l}
                aria-current={l === lang ? 'true' : undefined}
                onClick={(e) => {
                  e.preventDefault();
                  setOpen(false);
                  if (l !== lang) switchLanguage(l);
                }}
                className={`flex min-h-[48px] items-center justify-between px-4 text-base ${
                  l === lang ? 'bg-saffron-soft font-bold text-navy' : 'text-charcoal hover:bg-cream'
                }`}
              >
                <span className="native-name">{native[l].name}</span>
                <span className="native-name text-xs font-bold text-muted">{native[l].short}</span>
              </a>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/** Large segmented buttons (mobile drawer, footer) */
export function LanguageButtons({ lang, label, onDark = false }: { lang: Locale; label: string; onDark?: boolean }) {
  return (
    <div role="group" aria-label={label} className="flex gap-2">
      {locales.map((l) => (
        <a
          key={l}
          href={localePath[l]}
          lang={l}
          aria-current={l === lang ? 'true' : undefined}
          onClick={(e) => {
            e.preventDefault();
            if (l !== lang) switchLanguage(l);
          }}
          className={`flex min-h-[48px] flex-1 items-center justify-center rounded-md border-2 px-3 text-base font-bold transition-colors ${
            l === lang
              ? 'border-saffron bg-saffron text-navy'
              : onDark
                ? 'border-white/40 text-white hover:border-white'
                : 'border-navy/25 text-navy hover:border-navy'
          }`}
        >
          <span className="native-name">{native[l].name}</span>
        </a>
      ))}
    </div>
  );
}

/**
 * Remembers the visitor's language: if they chose ગુજરાતી/हिन्दी before and land on the
 * English page, take them to their language (same section). Runs once, client-side only.
 */
export function LanguageRestore({ lang }: { lang: Locale }) {
  useEffect(() => {
    try {
      const saved = localStorage.getItem(LANG_KEY) as Locale | null;
      if (lang === 'en' && saved && saved !== 'en' && (locales as readonly string[]).includes(saved)) {
        window.location.replace(localePath[saved] + window.location.hash);
      } else {
        localStorage.setItem(LANG_KEY, lang);
      }
    } catch {
      /* ignore */
    }
  }, [lang]);
  return null;
}
