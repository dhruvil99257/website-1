import type { Dictionary } from '@/i18n/types';
import { MeterIcon, RouteIcon, SeatIcon, SteeringIcon } from './Icons';

const icons = [SteeringIcon, SeatIcon, RouteIcon, MeterIcon];
const tints = ['bg-saffron-soft text-saffron-deep', 'bg-green-soft text-green', 'bg-[#E3ECF3] text-navy', 'bg-saffron-soft text-saffron-deep'];

/** Verified strengths only — no counters, because no numeric data was supplied (PRD §5.7). */
export default function WhyChooseUs({ t }: { t: Dictionary['why'] }) {
  return (
    <section id="why" aria-labelledby="why-title" className="section-y relative bg-white/60">
      <div className="container-x relative z-[2]">
        <div className="max-w-[640px]" data-reveal>
          <p className="eyebrow">{t.eyebrow}</p>
          <h2 id="why-title" className="h2 mt-3">
            {t.title}
          </h2>
          <p className="lead mt-4">{t.text}</p>
        </div>
        <ul className="mt-10 grid gap-4 sm:grid-cols-2">
          {t.items.map((item, i) => {
            const Icon = icons[i];
            return (
              <li key={item.title} className="card group flex gap-4 p-5 md:p-6" data-reveal>
                <span
                  className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl transition-transform duration-300 group-hover:-rotate-6 group-hover:scale-110 ${tints[i]}`}
                >
                  <Icon size={28} />
                </span>
                <div>
                  <h3 className="text-[1.2rem] font-bold">{item.title}</h3>
                  <p className="mt-1 text-muted">{item.text}</p>
                </div>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
