import type { Dictionary } from '@/i18n/types';
import { fmt } from '@/i18n';
import { activeFleet, seatLabel } from '@/config/fleet';
import FleetGrid from './FleetGrid';

export default function Fleet({ t, cta }: { t: Dictionary['fleet']; cta: Dictionary['cta'] }) {
  const items = activeFleet.map((v) => {
    const text = t.items[v.id] ?? { name: v.id, desc: '', idealFor: '', features: [] };
    return {
      id: v.id,
      art: v.art,
      image: v.image,
      isIllustrative: v.isIllustrative,
      seats: fmt(t.seats, { n: seatLabel(v) }),
      ...text,
    };
  });

  return (
    <section id="fleet" aria-labelledby="fleet-title" className="section-y relative">
      <div className="container-x relative z-[2]">
        <div className="max-w-[640px]" data-reveal>
          <p className="eyebrow">{t.eyebrow}</p>
          <h2 id="fleet-title" className="h2 mt-3">
            {t.title}
          </h2>
          <p className="lead mt-4">{t.text}</p>
        </div>
        <FleetGrid
          items={items}
          labels={{
            illustrative: t.illustrative,
            viewDetails: cta.viewDetails,
            enquire: cta.enquire,
            idealFor: t.idealFor,
            features: t.features,
            close: t.close,
          }}
        />
        <p className="mt-6 text-sm text-muted">{t.note}</p>
      </div>
    </section>
  );
}
