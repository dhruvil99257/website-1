import type { Dictionary } from '@/i18n/types';
import { fmt } from '@/i18n';
import { reviews } from '@/config/reviews';
import { business } from '@/config/business';
import { waLink } from '@/lib/whatsapp';
import { ChatIcon } from './Icons';

/**
 * Shows REAL reviews from src/config/reviews.ts. Never generates reviews or ratings.
 * While empty, shows an honest empty state inviting customers to share feedback.
 */
export default function Reviews({ t }: { t: Dictionary['reviews'] }) {
  return (
    <section id="reviews" aria-labelledby="reviews-title" className="section-y relative">
      <div className="container-x relative z-[2]">
        <div className="max-w-[640px]" data-reveal>
          <p className="eyebrow">{t.eyebrow}</p>
          <h2 id="reviews-title" className="h2 mt-3">
            {t.title}
          </h2>
        </div>

        {reviews.length === 0 ? (
          <div className="card mt-8 flex flex-col items-start gap-4 border-2 border-dashed border-navy/15 p-6 shadow-none md:flex-row md:items-center md:p-8" data-reveal>
            <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-saffron-soft text-3xl" aria-hidden="true">
              🙏
            </span>
            <div className="flex-1">
              <h3 className="text-[1.25rem] font-bold">{t.emptyTitle}</h3>
              <p className="mt-1 text-muted">{t.emptyText}</p>
            </div>
            <a href={waLink(business.whatsappNumber, t.shareText)} target="_blank" rel="noopener noreferrer" className="btn btn-secondary">
              <ChatIcon />
              {t.shareCta}
            </a>
          </div>
        ) : (
          <ul className="no-scrollbar -mx-4 mt-8 flex snap-x snap-proximity gap-4 overflow-x-auto px-4 pb-4 sm:-mx-6 sm:px-6">
            {reviews.map((r) => (
              <li key={r.id} className="card w-[84vw] max-w-[380px] shrink-0 snap-start p-6" data-reveal>
                <blockquote>
                  <p lang={r.lang} className="text-[1.05rem]">
                    “{r.text}”
                  </p>
                  <footer className="mt-4 text-sm">
                    <span className="font-bold text-navy">{r.name}</span>
                    {r.place && <span className="text-muted"> · {r.place}</span>}
                    <span className="block text-muted">{fmt(t.via, { source: r.source })}</span>
                  </footer>
                </blockquote>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
