/**
 * Illustrated Indian highway at sunrise (original artwork, inline SVG — zero image requests).
 * Layers carry data-depth for the gentle parallax set up in AnimationProvider.
 * viewBox 1440×600, anchored to the bottom so the road and bus stay visible on narrow phones.
 */
export default function HighwayScene({ label }: { label: string }) {
  return (
    <svg
      viewBox="0 0 1440 600"
      preserveAspectRatio="xMidYMax slice"
      className="h-full w-full"
      role="img"
      aria-label={label}
    >
      <defs>
        <linearGradient id="hs-road" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#5B6670" />
          <stop offset="1" stopColor="#2E353C" />
        </linearGradient>
        <linearGradient id="hs-haze" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#FBE3BD" stopOpacity=".95" />
          <stop offset="1" stopColor="#FBE3BD" stopOpacity="0" />
        </linearGradient>
        <radialGradient id="hs-sun" cx=".5" cy=".5" r=".5">
          <stop offset="0" stopColor="#FFD27A" />
          <stop offset=".6" stopColor="#F3A43B" />
          <stop offset="1" stopColor="#F3A43B" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* Sun + clouds */}
      <g data-depth="0.05">
        <circle cx="1040" cy="190" r="150" fill="url(#hs-sun)" opacity=".55" />
        <circle cx="1040" cy="190" r="62" fill="#F3A43B" />
      </g>
      <g className="drift" fill="#fff" opacity=".85">
        <path d="M180 120c10-22 44-26 58-8 16-14 46-6 48 16 20 0 30 22 14 30H170c-18-6-14-34 10-38z" />
        <path d="M1180 70c8-16 34-20 44-6 12-10 34-4 36 12 16 0 22 16 10 22h-98c-14-4-10-26 8-28z" />
      </g>
      {/* Birds */}
      <g fill="none" stroke="#173D5B" strokeWidth="3" strokeLinecap="round" opacity=".55">
        <path d="M860 110q10-10 20 0q10-10 20 0" />
        <path d="M910 140q7-7 14 0q7-7 14 0" />
      </g>

      {/* Far mountains + landmark silhouettes on the horizon */}
      <g data-depth="0.12">
        <path d="M0 240 120 170l90 50 110-90 140 110 90-60 120 80 70-30 100 40 120-90 130 90 110-60 130 70 110-40 100 50v190H0z" fill="#B9CFC2" />
        {/* temple shikhara */}
        <g fill="#8FAE9C">
          <path d="M268 232v-38l10-6v-14l8-6v-10l6-10 6 10v10l8 6v14l10 6v38z" />
          <path d="M292 148v-14" stroke="#8FAE9C" strokeWidth="2" />
          <path d="M293 134l12 4-12 4z" fill="#F3A43B" />
          <rect x="244" y="206" width="24" height="26" />
          <rect x="316" y="206" width="24" height="26" />
          <path d="M244 206l12-12 12 12zM316 206l12-12 12 12z" />
        </g>
        {/* fort with chhatris */}
        <g fill="#8FAE9C">
          <path d="M1150 232v-44h14v-10h12v10h18v-10h12v10h18v-10h12v10h14v44z" />
          <path d="M1172 178a12 12 0 0 1 24 0zM1214 178a12 12 0 0 1 24 0z" />
        </g>
      </g>

      {/* Mid hills */}
      <path data-depth="0.2" d="M0 300c140-60 260-70 380-40s220 20 330-20 250-40 380 10 230 50 350 20v330H0z" fill="#8DB89C" />
      {/* Near fields */}
      <g data-depth="0.3">
        <path d="M0 340c200-40 420-30 640 0s520 30 800-20v280H0z" fill="#6FAA86" />
        <path d="M0 420c260-30 520-10 760 20s440 10 680-30v190H0z" fill="#4D8865" />
        <g stroke="#5E9A76" strokeWidth="6" strokeLinecap="round" opacity=".7">
          <path d="M60 470l200-30M90 520l230-34M1180 470l200 20M1140 520l260 30" />
        </g>
      </g>

      {/* Road */}
      <path d="M706 232h28l190 368H516z" fill="url(#hs-road)" />
      <path d="M706 232 516 600M734 232l190 368" stroke="#F7F5EF" strokeWidth="5" />
      <path className="road-dash" d="M720 236V600" stroke="#F3A43B" strokeWidth="7" strokeDasharray="22 42" />
      <rect x="500" y="228" width="440" height="60" fill="url(#hs-haze)" />

      {/* Roadside: poles, palms, milestone */}
      <g data-depth="0.35">
        <g stroke="#2E353C" strokeWidth="4">
          <path d="M600 330v-70M552 410v-100M470 560V400" />
          <path d="M840 330v-70M888 410v-100M980 560V400" />
        </g>
        <g fill="none" stroke="#2E353C" strokeWidth="1.5" opacity=".6">
          <path d="M600 262q-24 30-48 50M552 312q-40 50-82 90" />
          <path d="M840 262q24 30 48 50M888 312q40 50 92 90" />
        </g>
        {/* palm trees */}
        <g>
          <path d="M360 560c-4-70 2-120 18-170" stroke="#7A5A3A" strokeWidth="10" fill="none" strokeLinecap="round" />
          <g fill="#2F6E4B">
            <path d="M378 392c-30-26-70-26-96-6 34-4 64 6 96 6z" />
            <path d="M378 392c-10-34-40-54-74-52 28 14 50 30 74 52z" />
            <path d="M378 392c20-32 56-44 88-34-30 4-58 16-88 34z" />
            <path d="M378 392c34-12 72 0 92 24-32-12-60-16-92-24z" />
            <path d="M378 392c-2-30 14-56 40-66-14 22-22 42-40 66z" />
          </g>
          <path d="M1110 560c4-60-2-104-16-146" stroke="#7A5A3A" strokeWidth="9" fill="none" strokeLinecap="round" />
          <g fill="#2F6E4B">
            <path d="M1094 416c28-22 64-22 88-4-30-2-58 6-88 4z" />
            <path d="M1094 416c8-30 36-48 66-46-24 12-44 26-66 46z" />
            <path d="M1094 416c-18-28-50-38-80-30 28 4 52 14 80 30z" />
            <path d="M1094 416c-30-10-66 0-84 22 30-10 54-14 84-22z" />
          </g>
        </g>
        {/* NH milestone (white with yellow top) */}
        <g transform="translate(1000 470)">
          <path d="M0 60V18a18 18 0 0 1 36 0v42z" fill="#F7F5EF" stroke="#2E353C" strokeWidth="2" />
          <path d="M0 22V18a18 18 0 0 1 36 0v4z" fill="#F3A43B" />
          <rect x="7" y="32" width="22" height="3" rx="1.5" fill="#2E353C" opacity=".5" />
          <rect x="10" y="40" width="16" height="3" rx="1.5" fill="#2E353C" opacity=".35" />
        </g>
        {/* small marigold bushes */}
        <g fill="#F3A43B">
          <circle cx="430" cy="566" r="8" />
          <circle cx="446" cy="572" r="7" />
          <circle cx="1060" cy="566" r="8" />
          <circle cx="1046" cy="574" r="6" />
        </g>
      </g>

      {/* Travel bus heading towards the horizon (rear view) */}
      <g transform="translate(652 418)">
        <ellipse cx="68" cy="142" rx="78" ry="10" fill="#1d2329" opacity=".35" />
        <g className="bob">
          <rect x="6" y="122" width="22" height="24" rx="5" fill="#1d2329" />
          <rect x="108" y="122" width="22" height="24" rx="5" fill="#1d2329" />
          <path d="M4 22Q4 4 22 4h92q18 0 18 18v104H4z" fill="#173D5B" />
          <rect x="16" y="16" width="104" height="44" rx="8" fill="#9FC3DA" />
          <path d="M16 46h104v14H16z" fill="#7EAAC6" />
          <rect x="4" y="70" width="128" height="10" fill="#F3A43B" />
          <rect x="4" y="82" width="128" height="5" fill="#4D8865" />
          <rect x="12" y="96" width="18" height="12" rx="3" fill="#FF6B4A" />
          <rect x="106" y="96" width="18" height="12" rx="3" fill="#FF6B4A" />
          <rect x="46" y="98" width="44" height="12" rx="2" fill="#F7F5EF" />
          <rect x="2" y="114" width="132" height="10" rx="4" fill="#0F2B41" />
          <rect x="30" y="0" width="76" height="6" rx="3" fill="#0F2B41" />
        </g>
      </g>
    </svg>
  );
}
