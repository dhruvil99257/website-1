import type { ReactNode } from 'react';
// Self-hosted fonts with unicode-range (see scripts/build-fonts.mjs): each page loads only the scripts it shows.
import '@/app/fonts.css';
import '@/app/globals.css';
import { htmlLang, type Locale } from '@/i18n';

/**
 * Shared <html>/<body> for each language's root layout.
 * Fontsource uses unicode-range, so a page only downloads the scripts it shows.
 */
const bootScript = `(function(){var d=document.documentElement;d.classList.add('js');try{var n=navigator,c=n.connection;if((n.hardwareConcurrency&&n.hardwareConcurrency<=4)||(c&&c.saveData))d.classList.add('lite');}catch(e){}})();`;

export default function RootShell({ lang, children }: { lang: Locale; children: ReactNode }) {
  return (
    <html lang={htmlLang[lang]} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: bootScript }} />
        <meta name="theme-color" content="#173D5B" />
        <link rel="icon" href="/favicon.svg" type="image/svg+xml" />
      </head>
      <body>{children}</body>
    </html>
  );
}
