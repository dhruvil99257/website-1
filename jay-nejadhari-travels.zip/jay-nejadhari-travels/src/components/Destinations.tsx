import type { Dictionary } from '@/i18n/types';
import { destinationIds } from '@/config/destinations';
import DestinationArt from './DestinationArt';
import GalleryRail from './GalleryRail';
import PrefillButton from './PrefillButton';
import { ArrowRightIcon } from './Icons';

export default function Destinations({ t }: { t: Dictionary['destinations'] }) {
  return (
    <section id="destinations" aria-labelledby="dest-title" className="section-y relative">
      <div className="container-x relative z-[2]">
        <div className="max-w-[640px]" data-reveal>
          <p className="eyebrow">{t.eyebrow}</p>
          <h2 id="dest-title" className="h2 mt-3">
            {t.title}
          </h2>
          <p className="lead mt-4">{t.text}</p>
        </div>

        <div className="mt-8" data-reveal>
          <GalleryRail prev={t.prev} next={t.next} hint={t.swipeHint}>
            {destinationIds.map((id) => {
              const d = t.items[id];
              return (
                <li key={id} className="group relative w-[78vw] max-w-[320px] shrink-0 snap-start overflow-hidden rounded-lg shadow-card">
                  <div className="aspect-[3/4]">
                    <DestinationArt id={id} />
                  </div>
                  <div className="absolute inset-x-0 bottom-0 bg-[linear-gradient(180deg,rgba(15,43,65,0)_0%,rgba(15,43,65,.9)_34%,#0F2B41_100%)] p-5 pt-14 text-white">
                    <h3 className="text-[1.45rem] font-extrabold !text-white">{d.name}</h3>
                    <p className="font-bold text-saffron">{d.tagline}</p>
                    <p className="mt-1 text-[0.92rem] text-white/80">{d.places}</p>
                    <PrefillButton
                      detail={{ destination: d.name }}
                      ariaLabel={`${t.planHere}: ${d.name}`}
                      className="mt-3 inline-flex min-h-[44px] items-center gap-2 rounded-md font-bold text-white underline-offset-4 hover:underline focus-visible:outline-saffron"
                    >
                      {t.planHere} <ArrowRightIcon size={18} />
                    </PrefillButton>
                  </div>
                </li>
              );
            })}
          </GalleryRail>
        </div>
      </div>
    </section>
  );
}
