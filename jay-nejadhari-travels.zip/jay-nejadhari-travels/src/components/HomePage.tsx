import { getDictionary, type Locale } from '@/i18n';
import { business } from '@/config/business';
import Header from './Header';
import Hero from './Hero';
import DiscoverIndia from './DiscoverIndia';
import Fleet from './Fleet';
import Services from './Services';
import Destinations from './Destinations';
import WhyChooseUs from './WhyChooseUs';
import Reviews from './Reviews';
import PlanJourney from './PlanJourney';
import Footer from './Footer';
import FloatingActions from './FloatingActions';
import SignatureRoad from './SignatureRoad';
import AnimationProvider from './AnimationProvider';
import JsonLd from './JsonLd';

/** The whole one-page site for a given language. Sections carry data-road-stop for the signature road. */
export default function HomePage({ lang }: { lang: Locale }) {
  const t = getDictionary(lang);
  return (
    <>
      <Header lang={lang} nav={t.nav} cta={{ call: t.cta.call, callShort: t.cta.callShort }} />
      <main id="main" className="relative">
        <Hero t={t.hero} cta={t.cta} />
        <SignatureRoad />
        <div data-road-stop>
          <DiscoverIndia t={t.india} dest={t.destinations} lang={lang} />
        </div>
        <div data-road-stop>
          <Fleet t={t.fleet} cta={t.cta} />
        </div>
        <div data-road-stop>
          <Services t={t.services} />
        </div>
        <div data-road-stop>
          <Destinations t={t.destinations} />
        </div>
        <div data-road-stop>
          <WhyChooseUs t={t.why} />
        </div>
        <div data-road-stop>
          <Reviews t={t.reviews} />
        </div>
        <div data-road-stop>
          <PlanJourney t={t} lang={lang} />
        </div>
      </main>
      <Footer t={t} lang={lang} />
      <FloatingActions
        phoneE164={business.phoneE164}
        whatsappNumber={business.whatsappNumber}
        waText={t.cta.quickWhatsappText}
        labels={{ call: t.cta.callShort, whatsapp: t.cta.whatsappShort }}
      />
      <AnimationProvider />
      <JsonLd lang={lang} t={t} />
    </>
  );
}
