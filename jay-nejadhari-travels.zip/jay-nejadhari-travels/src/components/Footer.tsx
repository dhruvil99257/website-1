import type { Dictionary, Locale } from '@/i18n/types';
import { business } from '@/config/business';
import { serviceIds } from '@/config/services';
import { telLink, waLink } from '@/lib/whatsapp';
import Logo from './Logo';
import { LanguageButtons } from './LanguageSwitcher';
import { NAV_SECTIONS } from '@/config/nav';
import { ArrowUpIcon, ChatIcon, LinkIcon, PhoneIcon, PinIcon } from './Icons';

const socialName = { instagram: 'Instagram', facebook: 'Facebook', youtube: 'YouTube', google: 'Google' } as const;

export default function Footer({ t, lang }: { t: Dictionary; lang: Locale }) {
  const year = new Date().getFullYear();
  return (
    <footer id="contact" className="on-dark relative bg-navy-deep text-white/85">
      <div className="container-x relative z-[2] grid gap-10 py-14 md:grid-cols-2 lg:grid-cols-[1.3fr_1fr_1fr_1.2fr]">
        <div>
          <Logo onDark />
          <p className="mt-4 max-w-[36ch]">{t.footer.tagline}</p>
          <div className="mt-6 flex flex-col gap-3 xs:flex-row">
            <a href={telLink(business.phoneE164)} className="btn btn-primary">
              <PhoneIcon /> {t.cta.call}
            </a>
            <a href={waLink(business.whatsappNumber, t.cta.quickWhatsappText)} target="_blank" rel="noopener noreferrer" className="btn btn-whatsapp">
              <ChatIcon /> {t.cta.whatsappShort}
            </a>
          </div>
        </div>

        <nav aria-label={t.footer.explore}>
          <h2 className="text-lg font-bold !text-white">{t.footer.explore}</h2>
          <ul className="mt-3">
            {NAV_SECTIONS.filter((s) => s !== 'contact').map((id) => (
              <li key={id}>
                <a href={`#${id}`} className="inline-flex min-h-[44px] min-w-[44px] items-center hover:text-saffron">
                  {t.nav[id]}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <nav aria-label={t.footer.servicesTitle}>
          <h2 className="text-lg font-bold !text-white">{t.footer.servicesTitle}</h2>
          <ul className="mt-3">
            {serviceIds.map((id) => (
              <li key={id}>
                <a href={`#service-${id}`} className="inline-flex min-h-[44px] min-w-[44px] items-center hover:text-saffron">
                  {t.services.items[id].title}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <h2 className="text-lg font-bold !text-white">{t.footer.contactTitle}</h2>
          <address className="mt-3 space-y-1 not-italic">
            <p className="font-bold text-white">{business.name}</p>
            <p className="flex min-h-[44px] items-center gap-2">
              <PinIcon size={18} className="shrink-0 text-saffron" />
              {business.addressLine ? `${business.addressLine}, ` : ''}
              {t.footer.location}
            </p>
            {business.mapsUrl && (
              <a href={business.mapsUrl} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-[44px] items-center gap-2 underline underline-offset-4 hover:text-saffron">
                <LinkIcon size={18} /> Google Maps
              </a>
            )}
            <a href={telLink(business.phoneE164)} className="flex min-h-[44px] items-center gap-2 hover:text-saffron">
              <PhoneIcon size={18} className="text-saffron" /> {business.phoneDisplay}
            </a>
            <a
              href={waLink(business.whatsappNumber, t.cta.quickWhatsappText)}
              target="_blank"
              rel="noopener noreferrer"
              className="flex min-h-[44px] items-center gap-2 hover:text-saffron"
            >
              <ChatIcon size={18} className="text-saffron" /> {t.cta.whatsappShort}: {business.phoneDisplay}
            </a>
            {business.email && (
              <a href={`mailto:${business.email}`} className="flex min-h-[44px] items-center gap-2 hover:text-saffron">
                {business.email}
              </a>
            )}
          </address>

          {business.socials.length > 0 && (
            <>
              <h3 className="mt-5 text-base font-bold !text-white">{t.footer.follow}</h3>
              <ul className="mt-2 flex flex-wrap gap-2">
                {business.socials.map((s) => (
                  <li key={s.url}>
                    <a href={s.url} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-[44px] items-center rounded-full border border-white/30 px-4 hover:border-saffron hover:text-saffron">
                      {socialName[s.network]}
                    </a>
                  </li>
                ))}
              </ul>
            </>
          )}

          <h3 className="mb-2 mt-6 text-base font-bold !text-white">{t.footer.languageTitle}</h3>
          <LanguageButtons lang={lang} label={t.footer.languageTitle} onDark />
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="container-x flex flex-col gap-3 py-6 text-sm text-white/60 md:flex-row md:items-center md:justify-between">
          <div>
            <p>
              © {year} {business.name}. {t.footer.rights}
            </p>
            <p className="mt-1 max-w-[80ch] text-xs text-white/50">{t.footer.credits}</p>
          </div>
          <a href="#top" className="inline-flex min-h-[44px] items-center gap-2 font-bold text-white hover:text-saffron">
            <ArrowUpIcon size={18} /> {t.footer.backToTop}
          </a>
        </div>
      </div>
    </footer>
  );
}
