import { business, siteUrl } from '@/config/business';
import { localePath, type Locale } from '@/i18n/types';
import type { Dictionary } from '@/i18n/types';

/**
 * LocalBusiness (TravelAgency) structured data — VERIFIED fields only.
 * No rating, review count, opening hours or street address until the owner supplies them.
 */
export default function JsonLd({ lang, t }: { lang: Locale; t: Dictionary }) {
  const data: Record<string, unknown> = {
    '@context': 'https://schema.org',
    '@type': 'TravelAgency',
    name: business.name,
    url: siteUrl + localePath[lang],
    telephone: business.phoneE164,
    description: t.meta.description,
    image: `${siteUrl}/og-image.png`,
    address: {
      '@type': 'PostalAddress',
      ...(business.addressLine ? { streetAddress: business.addressLine } : {}),
      addressLocality: business.city,
      addressRegion: business.state,
      addressCountry: business.countryCode,
    },
    areaServed: { '@type': 'Country', name: 'India' },
    availableLanguage: ['English', 'Gujarati', 'Hindi'],
    priceRange: '₹ per km',
    makesOffer: Object.values(t.services.items).map((s) => ({
      '@type': 'Offer',
      itemOffered: { '@type': 'Service', name: s.title, description: s.desc },
    })),
  };
  if (business.mapsUrl) data.hasMap = business.mapsUrl;
  if (business.socials.length) data.sameAs = business.socials.map((s) => s.url);

  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, '\\u003c') }} />;
}
