'use client';

import { useRef, useState } from 'react';
import type { VehicleArt as ArtKey } from '@/config/fleet';
import { requestPrefill } from '@/lib/prefill';
import { useTilt } from '@/lib/useTilt';
import VehicleArt from './VehicleArt';
import { CheckIcon, CloseIcon, UsersIcon } from './Icons';

export interface FleetItem {
  id: string;
  art: ArtKey;
  image?: string;
  isIllustrative: boolean;
  seats: string;
  name: string;
  desc: string;
  idealFor: string;
  features: string[];
}

interface Labels {
  illustrative: string;
  viewDetails: string;
  enquire: string;
  idealFor: string;
  features: string;
  close: string;
}

function Media({ item, labels }: { item: FleetItem; labels: Labels }) {
  return (
    <div className="relative aspect-[16/10] overflow-hidden bg-saffron-soft">
      {item.image ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={item.image} alt={item.name} width={1200} height={750} loading="lazy" decoding="async" className="zoom-media h-full w-full object-cover" />
      ) : (
        <VehicleArt art={item.art} className="zoom-media h-full w-full" />
      )}
      {item.isIllustrative && (
        <span className="absolute left-3 top-3 rounded-full bg-white/90 px-2.5 py-1 text-[0.72rem] font-bold text-muted">
          {labels.illustrative}
        </span>
      )}
      <span className="absolute right-3 top-3 inline-flex items-center gap-1.5 rounded-full bg-navy px-3 py-1.5 text-sm font-bold text-white">
        <UsersIcon size={16} className="text-saffron" />
        {item.seats}
      </span>
    </div>
  );
}

function VehicleCard({ item, labels, onDetails }: { item: FleetItem; labels: Labels; onDetails: () => void }) {
  const tilt = useTilt<HTMLElement>();
  return (
    <article ref={tilt} className="tilt group card flex flex-col overflow-hidden" data-reveal>
      <Media item={item} labels={labels} />
      <div className="flex flex-1 flex-col p-5">
        <h3 className="text-[1.3rem] font-bold">{item.name}</h3>
        <p className="mt-1.5 flex-1 text-muted">{item.desc}</p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button type="button" className="btn btn-secondary !px-3 text-[0.95rem]" onClick={onDetails} aria-haspopup="dialog">
            {labels.viewDetails}
          </button>
          <button type="button" className="btn btn-primary !px-3 text-[0.95rem]" onClick={() => requestPrefill({ seating: item.id })}>
            {labels.enquire}
          </button>
        </div>
      </div>
    </article>
  );
}

export default function FleetGrid({ items, labels }: { items: FleetItem[]; labels: Labels }) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [selected, setSelected] = useState<FleetItem | null>(null);

  const open = (item: FleetItem) => {
    setSelected(item);
    // showModal gives a native focus trap, Esc to close and an inert background
    requestAnimationFrame(() => dialog.current?.showModal());
  };
  const close = () => dialog.current?.close();

  return (
    <>
      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((item) => (
          <VehicleCard key={item.id} item={item} labels={labels} onDetails={() => open(item)} />
        ))}
      </div>

      <dialog
        ref={dialog}
        className="sheet bg-white text-charcoal"
        aria-labelledby="vehicle-dialog-title"
        onClick={(e) => {
          if (e.target === dialog.current) close(); // backdrop tap
        }}
      >
        {selected && (
          <div className="max-h-[92svh] overflow-y-auto">
            <div className="relative">
              <Media item={selected} labels={labels} />
              <button
                type="button"
                onClick={close}
                aria-label={labels.close}
                className="absolute right-3 top-3 flex h-11 w-11 items-center justify-center rounded-full bg-white text-navy shadow-card"
              >
                <CloseIcon />
              </button>
            </div>
            <div className="p-5 pb-[calc(20px+env(safe-area-inset-bottom))] md:p-7">
              <h3 id="vehicle-dialog-title" className="text-2xl font-extrabold">
                {selected.name}
              </h3>
              <p className="mt-2 text-muted">{selected.desc}</p>
              <h4 className="mt-5 text-base font-bold">{labels.idealFor}</h4>
              <p className="mt-1">{selected.idealFor}</p>
              <h4 className="mt-5 text-base font-bold">{labels.features}</h4>
              <ul className="mt-2 space-y-2">
                {selected.features.map((f) => (
                  <li key={f} className="flex items-start gap-2">
                    <CheckIcon size={20} className="mt-0.5 shrink-0 text-green" />
                    {f}
                  </li>
                ))}
              </ul>
              <button
                type="button"
                className="btn btn-primary mt-6 w-full"
                onClick={() => {
                  close();
                  requestPrefill({ seating: selected.id });
                }}
              >
                {labels.enquire}
              </button>
            </div>
          </div>
        )}
      </dialog>
    </>
  );
}
