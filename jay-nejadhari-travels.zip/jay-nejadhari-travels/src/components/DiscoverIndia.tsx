import type { Dictionary } from '@/i18n/types';
import { coverageDots, destinationIds, destinationPins, HOME_BASE } from '@/config/destinations';
import { project, routePath } from '@/lib/geo';
import IndiaMap from './IndiaMap';
import { INDIA_VIEWBOX } from './map/indiaPaths';

const suratName: Record<string, string> = { en: 'Surat', gu: 'સુરત', hi: 'सूरत' };

export default function DiscoverIndia({ t, dest, lang }: { t: Dictionary['india']; dest: Dictionary['destinations']; lang: string }) {
  const home = project(HOME_BASE.lat, HOME_BASE.lon);
  const destinations = destinationIds.map((id, i) => {
    const p = project(destinationPins[id].lat, destinationPins[id].lon);
    return {
      id,
      name: dest.items[id].name,
      places: dest.items[id].places,
      ...p,
      route: routePath(home, p, i % 2 ? 0.2 : -0.2),
    };
  });

  return (
    <section id="india" aria-labelledby="india-title" className="on-dark section-y relative bg-navy text-white">
      <div className="container-x relative z-[2]">
        <div className="max-w-[640px]" data-reveal>
          <p className="eyebrow !text-saffron">{t.eyebrow}</p>
          <h2 id="india-title" className="h2 mt-3 !text-white">
            {t.title}
          </h2>
          <p className="lead mt-4 !text-white/80">{t.text}</p>
        </div>

        <div className="mt-10" data-reveal>
          <IndiaMap
            viewBox={INDIA_VIEWBOX}
            statesLayer={
              // Outline served as a cached static file (public/images/india-map.svg) to keep HTML small
              <image href="/images/india-map.svg" x="0" y="0" width="612" height="696" />
            }
            home={home}
            dots={coverageDots.map((d) => project(d.lat, d.lon))}
            destinations={destinations}
            labels={{
              fromSurat: t.fromSurat,
              tapHint: t.tapHint,
              mapLabel: t.mapLabel,
              planHere: dest.planHere,
              surat: suratName[lang] ?? 'Surat',
            }}
          />
        </div>

        <div className="mt-10 grid gap-3 rounded-lg bg-white/5 p-5 sm:grid-cols-[auto_1fr] sm:items-center sm:gap-5" data-reveal>
          <span className="inline-flex w-fit rounded-full bg-saffron px-4 py-2 font-display text-lg font-extrabold text-navy">
            {t.coverageTitle}
          </span>
          <p className="text-white/85">{t.coverageText}</p>
        </div>
      </div>
    </section>
  );
}
