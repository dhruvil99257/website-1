import type { Dictionary } from '@/i18n/types';
import { serviceAccent, serviceIds } from '@/config/services';
import ServiceArt from './ServiceArt';
import PrefillButton from './PrefillButton';
import { ArrowRightIcon } from './Icons';

export default function Services({ t }: { t: Dictionary['services'] }) {
  return (
    <section id="services" aria-labelledby="services-title" className="section-y relative bg-white/60">
      <div className="container-x relative z-[2]">
        <div className="max-w-[640px]" data-reveal>
          <p className="eyebrow">{t.eyebrow}</p>
          <h2 id="services-title" className="h2 mt-3">
            {t.title}
          </h2>
          <p className="lead mt-4">{t.text}</p>
        </div>

        <ul className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {serviceIds.map((id) => (
            <li key={id} id={`service-${id}`} className="group card flex flex-col overflow-hidden" data-reveal>
              <div className="aspect-[12/7] overflow-hidden" style={{ background: serviceAccent[id] }}>
                <ServiceArt id={id} />
              </div>
              <div className="flex flex-1 flex-col p-5">
                <h3 className="text-[1.2rem] font-bold">{t.items[id].title}</h3>
                <p className="mt-1.5 flex-1 text-muted">{t.items[id].desc}</p>
                <PrefillButton
                  detail={{ tripType: id }}
                  ariaLabel={`${t.ask}: ${t.items[id].title}`}
                  className="mt-4 inline-flex min-h-[44px] w-fit items-center gap-2 rounded-md font-bold text-navy underline-offset-4 hover:text-saffron-deep hover:underline"
                >
                  {t.ask}
                  <ArrowRightIcon size={18} className="transition-transform group-hover:translate-x-1" />
                </PrefillButton>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
