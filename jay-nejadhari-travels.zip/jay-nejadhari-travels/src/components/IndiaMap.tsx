'use client';

import { useEffect, useState, type ReactNode } from 'react';
import { requestPrefill } from '@/lib/prefill';
import { ArrowRightIcon, PinIcon } from './Icons';

export interface MapDestination {
  id: string;
  name: string;
  places: string;
  x: number;
  y: number;
  route: string;
}

interface Props {
  home: { x: number; y: number };
  dots: { x: number; y: number }[];
  destinations: MapDestination[];
  labels: { fromSurat: string; tapHint: string; mapLabel: string; planHere: string; surat: string };
  /** Static state outlines, rendered on the server so they are not shipped as JavaScript */
  statesLayer: ReactNode;
  viewBox: string;
}

export default function IndiaMap({ home, dots, destinations, labels, statesLayer, viewBox }: Props) {
  const [active, setActive] = useState<string>(destinations[0]?.id ?? '');
  const [motionOk, setMotionOk] = useState(false);
  const current = destinations.find((d) => d.id === active);

  useEffect(() => {
    setMotionOk(!window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  }, []);

  return (
    <div className="grid items-center gap-8 lg:grid-cols-[1.1fr_1fr]">
      <div className="relative mx-auto w-full max-w-[560px]" data-map>
        <svg viewBox={viewBox} className="h-auto w-full" role="img" aria-label={labels.mapLabel}>
          {statesLayer}

          {/* coverage dots */}
          <g fill="#C9D3DC" opacity=".7">
            {dots.map((d, i) => (
              <circle key={i} cx={d.x} cy={d.y} r="3.2" />
            ))}
          </g>

          {/* routes from Surat */}
          <g fill="none" strokeLinecap="round">
            {destinations.map((d) => (
              <path
                key={d.id}
                d={d.route}
                data-draw
                stroke="#F3A43B"
                strokeWidth={d.id === active ? 4 : 2.2}
                strokeOpacity={d.id === active ? 1 : 0.45}
                style={{ transition: 'stroke-width .3s, stroke-opacity .3s' }}
              />
            ))}
          </g>

          {/* moving vehicle dot on the active route */}
          {motionOk && current && (
            <circle key={current.id} r="6" fill="#fff" stroke="#F3A43B" strokeWidth="3">
              <animateMotion dur="2.6s" repeatCount="indefinite" path={current.route} />
            </circle>
          )}

          {/* destination pins (tap targets enlarged with an invisible circle) */}
          {destinations.map((d) => (
            <g
              key={d.id}
              data-pin
              role="button"
              tabIndex={0}
              aria-label={d.name}
              aria-pressed={d.id === active}
              onClick={() => setActive(d.id)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setActive(d.id);
                }
              }}
              className="cursor-pointer outline-none [&:focus-visible>circle:nth-child(2)]:stroke-white"
            >
              <circle cx={d.x} cy={d.y} r="22" fill="transparent" />
              <circle cx={d.x} cy={d.y} r={d.id === active ? 9 : 7} fill={d.id === active ? '#F3A43B' : '#F7F5EF'} stroke="#173D5B" strokeWidth="2.5" />
            </g>
          ))}

          {/* Surat home pin */}
          <g aria-hidden="true">
            <circle className="pulse-ring" cx={home.x} cy={home.y} r="10" fill="#F3A43B" opacity=".6" />
            <circle cx={home.x} cy={home.y} r="9" fill="#F3A43B" stroke="#fff" strokeWidth="3" />
            <text x={home.x + 14} y={home.y + 5} fill="#fff" fontSize="17" fontWeight="700" style={{ fontFamily: 'var(--font-body)' }}>
              {labels.surat}
            </text>
          </g>
        </svg>
      </div>

      <div>
        <p className="mb-3 flex items-center gap-2 text-sm font-bold text-white/70">
          <PinIcon size={16} className="text-saffron" /> {labels.tapHint}
        </p>
        <ul className="flex flex-wrap gap-2">
          {destinations.map((d) => (
            <li key={d.id}>
              <button
                type="button"
                aria-pressed={d.id === active}
                onClick={() => setActive(d.id)}
                className={`min-h-[44px] rounded-full border-2 px-4 text-[0.95rem] font-bold transition-colors ${
                  d.id === active ? 'border-saffron bg-saffron text-navy' : 'border-white/30 text-white hover:border-white'
                }`}
              >
                {d.name}
              </button>
            </li>
          ))}
        </ul>

        {current && (
          <div className="mt-5 rounded-lg border border-white/15 bg-navy-soft p-5" aria-live="polite">
            <p className="text-sm font-bold text-saffron">
              {labels.surat} → {current.name}
            </p>
            <p className="mt-1 text-white/85">{current.places}</p>
            <button
              type="button"
              onClick={() => requestPrefill({ destination: current.name })}
              className="btn btn-ghost mt-4 !min-h-[44px] !px-4 text-[0.95rem]"
            >
              {labels.planHere} <ArrowRightIcon size={18} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
