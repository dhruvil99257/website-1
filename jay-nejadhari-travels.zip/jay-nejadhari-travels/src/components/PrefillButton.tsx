'use client';

import type { ReactNode } from 'react';
import { requestPrefill, type PrefillDetail } from '@/lib/prefill';

/** Any "Enquire / Plan a trip" action that pre-fills the inquiry form and scrolls to it. */
export default function PrefillButton({
  detail,
  className,
  children,
  ariaLabel,
}: {
  detail: PrefillDetail;
  className?: string;
  children: ReactNode;
  ariaLabel?: string;
}) {
  return (
    <button type="button" className={className} aria-label={ariaLabel} onClick={() => requestPrefill(detail)}>
      {children}
    </button>
  );
}
