'use client';

import { useEffect, useRef, useState } from 'react';
import type { Dictionary, Locale } from '@/i18n/types';
import { business } from '@/config/business';
import { telLink } from '@/lib/whatsapp';
import { NAV_SECTIONS } from '@/config/nav';
import Logo from './Logo';
import { LanguageButtons, LanguageMenu, LanguageRestore } from './LanguageSwitcher';
import { CloseIcon, MenuIcon, PhoneIcon } from './Icons';


interface Props {
  lang: Locale;
  nav: Dictionary['nav'];
  cta: Pick<Dictionary['cta'], 'call' | 'callShort'>;
}

export default function Header({ lang, nav, cta }: Props) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const menuBtn = useRef<HTMLButtonElement>(null);
  const drawer = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Drawer: lock background scroll, close on Esc, keep focus inside, restore focus on close.
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const first = drawer.current?.querySelector<HTMLElement>('a,button');
    first?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
      if (e.key === 'Tab' && drawer.current) {
        const items = Array.from(drawer.current.querySelectorAll<HTMLElement>('a,button'));
        const a = items[0];
        const z = items[items.length - 1];
        if (e.shiftKey && document.activeElement === a) {
          e.preventDefault();
          z.focus();
        } else if (!e.shiftKey && document.activeElement === z) {
          e.preventDefault();
          a.focus();
        }
      }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prev;
      document.removeEventListener('keydown', onKey);
      menuBtn.current?.focus();
    };
  }, [open]);

  const solid = scrolled || open;

  return (
    <>
      <LanguageRestore lang={lang} />
      <a
        href="#main"
        className="sr-only z-[70] rounded-md bg-saffron px-4 py-3 font-bold text-navy focus:not-sr-only focus:fixed focus:left-3 focus:top-3"
      >
        {nav.skip}
      </a>
      <header
        className={`fixed inset-x-0 top-0 z-[60] transition-[background-color,box-shadow] duration-300 ${
          solid ? 'on-dark bg-navy shadow-[0_6px_20px_-12px_rgba(0,0,0,.5)]' : 'bg-transparent'
        }`}
      >
        <div className="container-x flex h-[var(--header-h)] items-center justify-between gap-3">
          <a href="#top" className="flex min-h-[44px] items-center rounded-md">
            <Logo onDark={solid} />
          </a>

          <nav aria-label={nav.mainNav} className="hidden lg:block">
            <ul className="flex items-center gap-1">
              {NAV_SECTIONS.map((id) => (
                <li key={id}>
                  <a
                    href={`#${id}`}
                    className={`flex min-h-[44px] items-center rounded-md px-3 text-[0.95rem] font-bold transition-colors ${
                      solid ? 'text-white/90 hover:text-saffron' : 'text-navy hover:text-saffron-deep'
                    }`}
                  >
                    {nav[id]}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div className="flex items-center gap-2">
            <LanguageMenu lang={lang} label={nav.language} onDark={solid} />
            <a href={telLink(business.phoneE164)} className="btn btn-primary hidden !min-h-[44px] !px-4 md:inline-flex">
              <PhoneIcon size={18} />
              <span>{cta.call}</span>
            </a>
            <button
              ref={menuBtn}
              type="button"
              className={`flex h-12 w-12 items-center justify-center rounded-md lg:hidden ${solid ? 'text-white' : 'text-navy'}`}
              aria-expanded={open}
              aria-controls="mobile-nav"
              aria-label={open ? nav.closeMenu : nav.menu}
              onClick={() => setOpen((o) => !o)}
            >
              {open ? <CloseIcon size={26} /> : <MenuIcon size={26} />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile drawer */}
      <div
        id="mobile-nav"
        ref={drawer}
        role="dialog"
        aria-modal="true"
        aria-label={nav.mainNav}
        hidden={!open}
        className="on-dark fixed inset-x-0 bottom-0 top-[var(--header-h)] z-[55] overflow-y-auto bg-navy px-4 pb-[calc(24px+env(safe-area-inset-bottom))] pt-4 lg:hidden"
      >
        <nav aria-label={nav.mainNav}>
          <ul className="divide-y divide-white/10">
            {NAV_SECTIONS.map((id) => (
              <li key={id}>
                <a
                  href={`#${id}`}
                  onClick={() => setOpen(false)}
                  className="flex min-h-[56px] items-center justify-between font-display text-[1.35rem] font-bold text-white"
                >
                  {nav[id]}
                  <span aria-hidden="true" className="text-saffron">→</span>
                </a>
              </li>
            ))}
          </ul>
        </nav>
        <p className="mb-2 mt-6 text-sm font-bold uppercase tracking-wider text-white/60">{nav.language}</p>
        <LanguageButtons lang={lang} label={nav.language} onDark />
        <a href={telLink(business.phoneE164)} className="btn btn-primary mt-6 w-full">
          <PhoneIcon size={20} />
          {cta.call} · {business.phoneDisplay}
        </a>
      </div>
    </>
  );
}
