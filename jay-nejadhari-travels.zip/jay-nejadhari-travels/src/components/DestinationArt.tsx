import type { ReactElement } from 'react';
import type { DestinationId } from '@/config/destinations';

/**
 * Original illustrated scenes for each destination card (portrait, viewBox 320×400).
 * Lightweight SVG instead of photos; replace with licensed photos later if desired.
 */
const sky = (a: string, b: string, id: string) => (
  <defs>
    <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor={a} />
      <stop offset="1" stopColor={b} />
    </linearGradient>
  </defs>
);

const scenes: Record<DestinationId, ReactElement> = {
  gujarat: (
    <>
      {sky('#FBE3BD', '#F7C27A', 'g-sky')}
      <rect width="320" height="400" fill="url(#g-sky)" />
      <circle cx="232" cy="96" r="38" fill="#F3A43B" />
      {/* Dwarka-style temple */}
      <g fill="#C46A1E">
        <path d="M120 250v-60l12-8v-26l12-8v-22l16-26 16 26v22l12 8v26l12 8v60z" />
        <rect x="88" y="208" width="32" height="42" />
        <rect x="200" y="208" width="32" height="42" />
        <path d="M88 208l16-16 16 16zM200 208l16-16 16 16z" />
      </g>
      <path d="M160 74V48" stroke="#173D5B" strokeWidth="3" />
      <path d="M161 48l30 10-30 10z" fill="#E8743B" />
      {/* sea */}
      <path d="M0 250h320v150H0z" fill="#3E7FA3" />
      <path d="M0 270q20-8 40 0t40 0 40 0 40 0 40 0 40 0 40 0 40 0" stroke="#9FC3DA" strokeWidth="3" fill="none" />
      <path d="M0 300q20-8 40 0t40 0 40 0 40 0 40 0 40 0 40 0 40 0" stroke="#9FC3DA" strokeWidth="3" fill="none" opacity=".6" />
    </>
  ),
  rajasthan: (
    <>
      {sky('#FCE9CC', '#F3A43B', 'r-sky')}
      <rect width="320" height="400" fill="url(#r-sky)" />
      <circle cx="80" cy="110" r="34" fill="#FFD27A" />
      {/* fort */}
      <g fill="#B8603A">
        <path d="M60 240v-70h18v-12h14v12h20v-12h14v12h20v-12h14v12h20v-12h14v12h20v-12h14v12h18v70z" />
        <path d="M100 170a16 16 0 0 1 32 0zM188 170a16 16 0 0 1 32 0z" />
        <rect x="150" y="200" width="20" height="40" rx="10" fill="#7A3B22" />
      </g>
      {/* dunes */}
      <path d="M0 260q80-40 160 0t160-10v150H0z" fill="#E8B062" />
      <path d="M0 310q100-40 200 0t120-6v96H0z" fill="#D9861A" />
      {/* camel */}
      <g fill="#7A3B22" transform="translate(196 236)">
        <path d="M0 30q6-22 22-20 6-14 16-4 8-10 14 4l10-10q8-2 8 8l-6 6-8 16v26h-5V40H22v16h-5V36q-10 6-17-6z" />
      </g>
    </>
  ),
  goa: (
    <>
      {sky('#FBE3BD', '#FF9E6B', 'go-sky')}
      <rect width="320" height="400" fill="url(#go-sky)" />
      <circle cx="160" cy="200" r="54" fill="#FFD27A" />
      <path d="M0 210h320v190H0z" fill="#2F7DA0" />
      <path d="M118 230h84M128 246h64M140 262h40" stroke="#FFD27A" strokeWidth="4" strokeLinecap="round" opacity=".7" />
      <path d="M0 320q160-40 320 10v70H0z" fill="#F4D49A" />
      {/* palms */}
      <g>
        <path d="M54 340c-6-60 0-110 20-160" stroke="#5A3E26" strokeWidth="9" fill="none" strokeLinecap="round" />
        <g fill="#2F6E4B">
          <path d="M74 180c-34-26-74-22-96 0 36-8 66 2 96 0z" />
          <path d="M74 180c-8-36-38-56-70-52 28 14 48 30 70 52z" />
          <path d="M74 180c22-30 58-40 88-28-32 2-58 12-88 28z" />
          <path d="M74 180c34-6 70 8 86 34-30-16-56-22-86-34z" />
        </g>
        <path d="M282 350c4-40-2-70-14-100" stroke="#5A3E26" strokeWidth="7" fill="none" strokeLinecap="round" />
        <g fill="#2F6E4B">
          <path d="M268 250c24-18 54-16 72 2-26-6-48 0-72-2z" />
          <path d="M268 250c-16-22-44-28-68-18 24 2 46 8 68 18z" />
          <path d="M268 250c6-26 28-40 54-38-22 10-38 22-54 38z" />
        </g>
      </g>
    </>
  ),
  kashmir: (
    <>
      {sky('#DCEBF5', '#B9D4E6', 'k-sky')}
      <rect width="320" height="400" fill="url(#k-sky)" />
      <path d="M0 230l70-110 50 60 50-90 70 100 40-40 40 60v40H0z" fill="#7E9DB5" />
      <path d="M70 120l18 28-12-4-10 10zM170 90l20 32-14-6-12 12-10-8zM280 170l14 20-10-4z" fill="#fff" />
      <path d="M0 230l60-60 40 30 60-50 60 50 50-30 50 40v30H0z" fill="#4D7A93" />
      {/* pines */}
      <g fill="#2F5E4B">
        {[20, 50, 260, 292].map((x, i) => (
          <path key={x} d={`M${x} ${250 - (i % 2) * 10}l14 30h-8l12 26h-36l12-26h-8z`} />
        ))}
      </g>
      {/* Dal lake + shikara */}
      <path d="M0 270h320v130H0z" fill="#5E95B5" />
      <path d="M40 300h240M70 330h180" stroke="#B9D4E6" strokeWidth="3" strokeLinecap="round" opacity=".7" />
      <g transform="translate(96 300)">
        <path d="M0 20q64 22 128 0l-10 12H10z" fill="#7A3B22" />
        <rect x="34" y="0" width="60" height="20" rx="3" fill="#E8743B" />
        <path d="M30 0h68l-6-10H36z" fill="#F3A43B" />
      </g>
    </>
  ),
  maharashtra: (
    <>
      {sky('#FBE3BD', '#E8C99A', 'm-sky')}
      <rect width="320" height="400" fill="url(#m-sky)" />
      {/* Western Ghats */}
      <path d="M0 210l40-40 30 20 40-60 40 50 30-20 50 40 40-30 50 50v190H0z" fill="#6FAA86" />
      <path d="M0 250l60-30 50 20 60-40 60 40 40-20 50 30v150H0z" fill="#4D8865" />
      {/* waterfall */}
      <path d="M150 150v110" stroke="#DCEBF5" strokeWidth="8" strokeLinecap="round" />
      <path d="M150 150v110" stroke="#fff" strokeWidth="3" strokeDasharray="10 10" />
      {/* hill fort */}
      <g fill="#7A6A55">
        <path d="M200 160v-24h10v-8h10v8h14v-8h10v8h10v24z" />
      </g>
      {/* road through ghats */}
      <path d="M40 400c40-60 160-40 140-110s80-60 120-70" stroke="#5B6670" strokeWidth="18" fill="none" strokeLinecap="round" />
      <path d="M40 400c40-60 160-40 140-110s80-60 120-70" stroke="#F3A43B" strokeWidth="2.5" strokeDasharray="10 10" fill="none" />
    </>
  ),
  kerala: (
    <>
      {sky('#E3F0E6', '#BFE0C9', 'ke-sky')}
      <rect width="320" height="400" fill="url(#ke-sky)" />
      {/* tea hills */}
      <path d="M0 190q80-60 160-10t160-20v80H0z" fill="#6FAA86" />
      <g stroke="#4D8865" strokeWidth="5" fill="none" strokeLinecap="round" opacity=".8">
        <path d="M20 200q60-30 120 0M40 220q70-30 140 0M180 190q60-30 120-4M200 214q50-24 110 0" />
      </g>
      {/* backwater */}
      <path d="M0 240h320v160H0z" fill="#3E8C7E" />
      <path d="M30 280h120M170 300h120M60 330h200" stroke="#BFE0C9" strokeWidth="3" strokeLinecap="round" opacity=".6" />
      {/* houseboat */}
      <g transform="translate(80 256)">
        <path d="M0 30q80 24 160 0l-14 16H14z" fill="#5A3E26" />
        <path d="M18 30V14q62-30 124 0v16z" fill="#C49A5A" />
        <path d="M30 12q50-24 100 0" stroke="#7A5A3A" strokeWidth="3" fill="none" />
        <rect x="46" y="18" width="14" height="10" rx="2" fill="#F7F5EF" />
        <rect x="74" y="16" width="14" height="12" rx="2" fill="#F7F5EF" />
        <rect x="102" y="18" width="14" height="10" rx="2" fill="#F7F5EF" />
      </g>
      {/* coconut palms */}
      <g>
        <path d="M290 250c-4-50 0-90-16-130" stroke="#5A3E26" strokeWidth="7" fill="none" strokeLinecap="round" />
        <g fill="#2F6E4B">
          <path d="M274 120c-30-18-62-12-80 6 30-8 54 0 80-6z" />
          <path d="M274 120c20-24 50-28 72-12-26 0-48 4-72 12z" />
          <path d="M274 120c-2-30 20-50 44-52-18 14-30 30-44 52z" />
        </g>
      </g>
    </>
  ),
  himachal: (
    <>
      {sky('#E3ECF3', '#C3D6E6', 'h-sky')}
      <rect width="320" height="400" fill="url(#h-sky)" />
      <path d="M0 200l80-120 60 70 60-100 120 150v60H0z" fill="#8FA9BF" />
      <path d="M80 80l20 30-14-6-10 12zM200 50l26 40-18-8-12 14-12-10z" fill="#fff" />
      <path d="M0 230l70-60 70 40 70-50 110 70v170H0z" fill="#4D8865" />
      {/* deodar trees */}
      <g fill="#2F5E4B">
        {[16, 44, 72, 236, 266, 296].map((x, i) => (
          <path key={x} d={`M${x} ${220 + (i % 3) * 8}l16 34h-9l14 30h-42l14-30h-9z`} />
        ))}
      </g>
      {/* winding mountain road */}
      <path d="M160 400c-80-40 80-60 0-100s60-50 40-90" stroke="#5B6670" strokeWidth="16" fill="none" strokeLinecap="round" />
      <path d="M160 400c-80-40 80-60 0-100s60-50 40-90" stroke="#F7F5EF" strokeWidth="2" strokeDasharray="8 10" fill="none" />
    </>
  ),
  uttarakhand: (
    <>
      {sky('#FCE9CC', '#F6CF94', 'u-sky')}
      <rect width="320" height="400" fill="url(#u-sky)" />
      <path d="M0 180l60-80 50 50 60-90 70 90 40-30 40 50v60H0z" fill="#9DB7A8" />
      <path d="M170 60l18 28-12-6-10 10zM60 100l14 20-10-4z" fill="#fff" />
      <path d="M0 220l80-50 70 40 90-60 80 50v200H0z" fill="#4D8865" />
      {/* Ganga */}
      <path d="M120 400c10-60 60-100 40-160s30-40 60-50h40c-40 20-60 30-50 70s-10 100-30 140z" fill="#7FB8C9" />
      {/* suspension bridge */}
      <path d="M40 252h240" stroke="#7A3B22" strokeWidth="5" />
      <path d="M60 252V214M260 252V214" stroke="#7A3B22" strokeWidth="6" />
      <path d="M60 214q100 50 200 0" stroke="#173D5B" strokeWidth="2.5" fill="none" />
      <g stroke="#173D5B" strokeWidth="1.5">
        {[90, 120, 150, 180, 210, 240].map((x) => (
          <path key={x} d={`M${x} 252v-${Math.round(14 + Math.abs(160 - x) * 0.2)}`} />
        ))}
      </g>
      {/* small temple on the bank */}
      <g fill="#E8743B" transform="translate(242 270)">
        <path d="M0 40V24l8-6V8l8-12 8 12v10l8 6v16z" />
      </g>
    </>
  ),
};

export default function DestinationArt({ id }: { id: DestinationId }) {
  return (
    <svg viewBox="0 0 320 400" className="zoom-media h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      {scenes[id]}
    </svg>
  );
}
