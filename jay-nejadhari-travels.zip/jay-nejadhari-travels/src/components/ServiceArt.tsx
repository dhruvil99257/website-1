import type { ReactElement } from 'react';
import type { ServiceId } from '@/config/services';

/** Small original illustrations for the 7 service cards. viewBox 240×140. */
const N = '#173D5B';
const S = '#F3A43B';
const G = '#4D8865';
const C = '#F7F5EF';

function Ground() {
  return <path d="M0 116c60-10 120-10 240 0v24H0z" fill={G} opacity=".25" />;
}

function MiniCar({ x, y, color = N }: { x: number; y: number; color?: string }) {
  return (
    <g transform={`translate(${x} ${y})`}>
      <path d="M0 18v-6q0-4 5-5l8-1 7-6h16l8 6 6 1q4 1 4 5v6z" fill={color} />
      <path d="M22 2h12l6 5H17z" fill="#9FC3DA" />
      <circle cx="12" cy="19" r="4.5" fill="#242A30" />
      <circle cx="42" cy="19" r="4.5" fill="#242A30" />
    </g>
  );
}

const arts: Record<ServiceId, ReactElement> = {
  local: (
    <>
      <Ground />
      <g fill={N} opacity=".85">
        <rect x="30" y="56" width="26" height="60" rx="2" />
        <rect x="60" y="40" width="22" height="76" rx="2" />
        <rect x="86" y="66" width="30" height="50" rx="2" />
        <rect x="150" y="50" width="24" height="66" rx="2" />
        <rect x="178" y="70" width="30" height="46" rx="2" />
      </g>
      <g fill={C} opacity=".9">
        {[64, 76, 88, 100].map((y) => (
          <rect key={y} x="66" y={y - 18} width="10" height="5" rx="1" />
        ))}
        {[62, 78, 94].map((y) => (
          <rect key={y} x="156" y={y} width="12" height="5" rx="1" />
        ))}
      </g>
      <path d="M128 18a18 18 0 0 1 18 18c0 14-18 32-18 32s-18-18-18-32a18 18 0 0 1 18-18z" fill={S} />
      <circle cx="128" cy="36" r="6.5" fill={C} />
      <MiniCar x={96} y={100} color={S} />
    </>
  ),
  outstation: (
    <>
      <path d="M0 84l50-30 40 20 50-36 50 30 50-20v92H0z" fill={G} opacity=".35" />
      <path d="M0 100c60-12 140-14 240-4v44H0z" fill={G} opacity=".45" />
      <path d="M112 64h16l50 76H62z" fill="#5B6670" />
      <path d="M120 66v74" stroke={S} strokeWidth="3" strokeDasharray="8 8" />
      <g transform="translate(186 92)">
        <path d="M0 30V10a10 10 0 0 1 20 0v20z" fill={C} stroke="#242A30" strokeWidth="1.5" />
        <path d="M0 12v-2a10 10 0 0 1 20 0v2z" fill={S} />
      </g>
      <circle cx="196" cy="34" r="14" fill={S} opacity=".8" />
    </>
  ),
  oneway: (
    <>
      <Ground />
      <rect x="0" y="96" width="240" height="22" fill="#5B6670" />
      <path d="M0 107h240" stroke={C} strokeWidth="3" strokeDasharray="12 10" />
      <rect x="60" y="40" width="5" height="56" fill="#242A30" />
      <path d="M40 30h80l18 14-18 14H40z" fill={N} />
      <path d="M56 44h48m0 0-10-8m10 8-10 8" stroke={S} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <rect x="188" y="44" width="4" height="52" fill="#242A30" />
      <path d="M192 44h28l-8 9 8 9h-28z" fill={S} />
      <MiniCar x={120} y={84} />
    </>
  ),
  roundtrip: (
    <>
      <Ground />
      <ellipse cx="120" cy="74" rx="78" ry="40" fill="none" stroke="#5B6670" strokeWidth="14" />
      <ellipse cx="120" cy="74" rx="78" ry="40" fill="none" stroke={C} strokeWidth="2" strokeDasharray="8 8" />
      <path d="M196 70l8 12-14 0z" fill={S} />
      <path d="M44 78l-8-12 14 0z" fill={S} />
      <circle cx="120" cy="34" r="9" fill={S} stroke={C} strokeWidth="3" />
      <circle cx="120" cy="114" r="9" fill={N} stroke={C} strokeWidth="3" />
      <MiniCar x={150} y={96} color={G} />
    </>
  ),
  wedding: (
    <>
      <path d="M10 14q110 40 220 0" fill="none" stroke={G} strokeWidth="2" />
      {Array.from({ length: 9 }).map((_, i) => {
        const x = 26 + i * 24;
        const y = 14 + Math.sin((i / 8) * Math.PI) * 18;
        return <path key={i} d={`M${x - 7} ${y}h14l-7 14z`} fill={i % 2 ? S : '#E8743B'} />;
      })}
      <Ground />
      <g transform="translate(46 64)">
        <path d="M0 46V34q0-8 10-10l22-4 20-16q6-4 14-4h28q8 0 14 5l20 15 16 3q10 2 10 12v12z" fill={C} stroke={N} strokeWidth="2.5" />
        <path d="M58 6h34l18 16H50z" fill="#9FC3DA" />
        <circle cx="34" cy="48" r="10" fill="#242A30" />
        <circle cx="122" cy="48" r="10" fill="#242A30" />
        {/* marigold garland */}
        <path d="M8 30q70 26 140 0" fill="none" stroke={S} strokeWidth="6" strokeDasharray="1 7" strokeLinecap="round" />
        <circle cx="78" cy="2" r="7" fill="#E8743B" />
        <circle cx="72" cy="0" r="4" fill={S} />
        <circle cx="85" cy="0" r="4" fill={S} />
      </g>
    </>
  ),
  corporate: (
    <>
      <Ground />
      <g fill={N}>
        <rect x="24" y="24" width="44" height="92" rx="3" />
        <rect x="74" y="46" width="34" height="70" rx="3" opacity=".75" />
      </g>
      <g fill="#9FC3DA">
        {[34, 50, 66, 82, 98].map((y) => (
          <g key={y}>
            <rect x="32" y={y} width="10" height="8" rx="1" />
            <rect x="50" y={y} width="10" height="8" rx="1" />
          </g>
        ))}
      </g>
      <g transform="translate(120 72)">
        <path d="M0 40V8q0-8 8-8h80q8 0 12 8l8 16v16z" fill={S} />
        {[8, 28, 48, 68].map((x) => (
          <rect key={x} x={x} y="8" width="16" height="14" rx="2" fill="#9FC3DA" />
        ))}
        <circle cx="22" cy="42" r="7" fill="#242A30" />
        <circle cx="86" cy="42" r="7" fill="#242A30" />
      </g>
    </>
  ),
  pilgrimage: (
    <>
      <Ground />
      <g fill={S}>
        <path d="M96 116V84l8-6V62l8-6V44l8-12 8 12v12l8 6v16l8 6v32z" />
        <rect x="70" y="92" width="26" height="24" />
        <rect x="144" y="92" width="26" height="24" />
        <path d="M70 92l13-12 13 12zM144 92l13-12 13 12z" />
      </g>
      <path d="M120 32V12" stroke={N} strokeWidth="2.5" />
      <path d="M121 12l20 6-20 6z" fill="#E8743B" />
      <path d="M110 116v-14a10 10 0 0 1 20 0v14z" fill={N} />
      <g transform="translate(186 98)">
        <path d="M0 8q12 12 24 0z" fill="#C46A1E" />
        <path d="M12 6q-6-6 0-14 6 8 0 14z" fill={S} />
      </g>
      <rect x="60" y="116" width="120" height="6" fill={N} opacity=".3" />
    </>
  ),
};

export default function ServiceArt({ id }: { id: ServiceId }) {
  return (
    <svg viewBox="0 0 240 140" className="zoom-media h-full w-full" aria-hidden="true">
      {arts[id]}
    </svg>
  );
}
