'use client';

import { useEffect, useState } from 'react';
import { telLink, waLink } from '@/lib/whatsapp';
import { ChatIcon, PhoneIcon } from './Icons';

interface Props {
  phoneE164: string;
  whatsappNumber: string;
  waText: string;
  labels: { call: string; whatsapp: string };
}

/**
 * Mobile: fixed bottom bar (page reserves its height via --bar-h, so nothing is covered).
 * Desktop: two round buttons bottom-right.
 * Slides away while the hero CTAs or the form's submit button are on screen, to avoid duplicates.
 */
export default function FloatingActions({ phoneE164, whatsappNumber, waText, labels }: Props) {
  const [hidden, setHidden] = useState(true);

  useEffect(() => {
    const watched = [document.querySelector('#top .btn'), document.querySelector('[data-submit-zone]')].filter(Boolean) as Element[];
    const visible = new Set<Element>();
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => (e.isIntersecting ? visible.add(e.target) : visible.delete(e.target)));
        setHidden(visible.size > 0);
      },
      { threshold: 0.2 },
    );
    watched.forEach((el) => io.observe(el));
    if (!watched.length) setHidden(false);
    return () => io.disconnect();
  }, []);

  const call = telLink(phoneE164);
  const wa = waLink(whatsappNumber, waText);

  return (
    <>
      {/* mobile bar */}
      <div
        className={`fixed inset-x-0 bottom-0 z-50 grid grid-cols-2 gap-2 bg-white/95 px-3 pt-2 shadow-[0_-8px_24px_-12px_rgba(23,61,91,.35)] transition-transform duration-300 md:hidden ${
          hidden ? 'translate-y-full' : 'translate-y-0'
        }`}
        style={{ paddingBottom: 'calc(8px + env(safe-area-inset-bottom, 0px))' }}
        aria-hidden={hidden}
      >
        <a href={call} className="btn btn-primary !min-h-[48px]" tabIndex={hidden ? -1 : 0}>
          <PhoneIcon /> {labels.call}
        </a>
        <a href={wa} target="_blank" rel="noopener noreferrer" className="btn btn-whatsapp !min-h-[48px]" tabIndex={hidden ? -1 : 0}>
          <ChatIcon /> {labels.whatsapp}
        </a>
      </div>

      {/* desktop floating buttons */}
      <div
        className={`fixed bottom-6 right-6 z-50 hidden flex-col gap-3 transition-[opacity,transform] duration-300 md:flex ${
          hidden ? 'pointer-events-none translate-y-4 opacity-0' : 'opacity-100'
        }`}
        aria-hidden={hidden}
      >
        <a href={wa} target="_blank" rel="noopener noreferrer" aria-label={labels.whatsapp} title={labels.whatsapp} tabIndex={hidden ? -1 : 0}
          className="flex h-14 w-14 items-center justify-center rounded-full bg-whatsapp text-white shadow-lift transition-transform hover:scale-105">
          <ChatIcon size={26} />
        </a>
        <a href={call} aria-label={labels.call} title={labels.call} tabIndex={hidden ? -1 : 0}
          className="flex h-14 w-14 items-center justify-center rounded-full bg-saffron text-navy shadow-lift transition-transform hover:scale-105">
          <PhoneIcon size={24} />
        </a>
      </div>
    </>
  );
}
