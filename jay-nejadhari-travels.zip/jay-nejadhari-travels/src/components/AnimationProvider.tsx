'use client';

import { useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

/**
 * Central animation controller (DESIGN.md §7).
 * - GSAP only animates transform/opacity/stroke-dashoffset.
 * - Reveals run once (no awkward restarts when scrolling back up).
 * - Nothing is pinned and nothing hijacks native scrolling.
 * - prefers-reduced-motion → no animation at all (CSS keeps everything visible).
 * - "lite" devices (≤4 cores or Save-Data) → no parallax.
 */
export default function AnimationProvider() {
  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    ScrollTrigger.config({ ignoreMobileResize: true });
    const lite = document.documentElement.classList.contains('lite');
    const mm = gsap.matchMedia();

    mm.add('(prefers-reduced-motion: no-preference)', () => {
      // 1. Hero entrance: text animates with CSS (instant, see globals.css); the scene rises in here
      gsap.from('.hero-scene', { opacity: 0, y: 30, duration: 1, ease: 'power3.out', delay: 0.1 });

      // 2. Staggered section reveals (once)
      const reveal = (els: Element[]) =>
        gsap.to(els, {
          opacity: 1,
          y: 0,
          duration: 0.7,
          ease: 'power3.out',
          stagger: 0.08,
          overwrite: true,
          onComplete: () =>
            els.forEach((el) => {
              el.classList.add('revealed');
              gsap.set(el, { clearProps: 'transform,opacity' });
            }),
        });
      const all = gsap.utils.toArray<HTMLElement>('[data-reveal]');
      // Anything already on/above screen (e.g. arriving via #anchor) appears immediately.
      const vh = window.innerHeight;
      const already = all.filter((el) => el.getBoundingClientRect().top < vh * 0.92);
      if (already.length) reveal(already);
      ScrollTrigger.batch(
        all.filter((el) => !already.includes(el)),
        { start: 'top 90%', once: true, onEnter: (batch) => reveal(batch as Element[]) },
      );

      // 3. India map: routes draw from Surat, pins pop in
      const routes = gsap.utils.toArray<SVGPathElement>('[data-draw]');
      routes.forEach((p) => {
        const l = p.getTotalLength();
        gsap.set(p, { strokeDasharray: l, strokeDashoffset: l });
      });
      gsap
        .timeline({ scrollTrigger: { trigger: '[data-map]', start: 'top 75%', once: true } })
        .to(routes, { strokeDashoffset: 0, duration: 1.1, ease: 'power2.inOut', stagger: 0.12 })
        .from('[data-pin]', { scale: 0, transformOrigin: '50% 50%', duration: 0.4, ease: 'back.out(2)', stagger: 0.08 }, 0.5);

      // 4. Gentle hero parallax (skipped on lite devices)
      if (!lite) {
        gsap.utils.toArray<SVGGElement>('#top [data-depth]').forEach((layer) => {
          const depth = parseFloat(layer.dataset.depth || '0');
          gsap.to(layer, {
            y: depth * 220,
            ease: 'none',
            scrollTrigger: { trigger: '#top', start: 'top top', end: 'bottom top', scrub: 0.4 },
          });
        });
      }
    });

    // Pause looping CSS animations (road dashes, wheels, clouds) when the hero is off-screen
    const hero = document.querySelector('.hero-scene');
    let io: IntersectionObserver | undefined;
    if (hero) {
      io = new IntersectionObserver(([e]) => hero.classList.toggle('paused', !e.isIntersecting));
      io.observe(hero);
    }

    // Re-measure after web fonts load (text reflow changes trigger positions)
    document.fonts?.ready.then(() => ScrollTrigger.refresh()).catch(() => {});

    return () => {
      mm.revert();
      io?.disconnect();
    };
  }, []);

  return null;
}
