import type React from 'react';
import type { Dictionary } from '@/i18n/types';
import { business } from '@/config/business';
import { telLink, waLink } from '@/lib/whatsapp';
import HighwayScene from './HighwayScene';
import { ChatIcon, PhoneIcon } from './Icons';

export default function Hero({ t, cta }: { t: Dictionary['hero']; cta: Dictionary['cta'] }) {
  return (
    <section
      id="top"
      aria-labelledby="hero-title"
      className="relative flex min-h-[100svh] flex-col overflow-hidden bg-[linear-gradient(180deg,#F7F5EF_0%,#FBEFD9_55%,#FBE3BD_100%)]"
    >
      <div className="container-x relative z-[2] pt-[calc(var(--header-h)+24px)] md:pt-[calc(var(--header-h)+48px)]">
        <div className="max-w-[620px]">
          {business.logoSrc && (
            // Supplied logo, shown large in the hero once configured
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={business.logoSrc}
              alt={business.name}
              width={business.logoWidth}
              height={business.logoHeight}
              className="hero-in mb-4 h-14 w-auto"
            />
          )}
          <p className="eyebrow hero-in" style={{ '--i': 0 } as React.CSSProperties}>{t.eyebrow}</p>
          <h1
            id="hero-title"
            className="hero-in hero-title mt-3 font-extrabold text-navy"
            style={{ '--i': 1, fontSize: 'clamp(2.25rem, 1.4rem + 4.2vw, 4.25rem)', lineHeight: 1.05 } as React.CSSProperties}
          >
            {t.title}
          </h1>
          <p style={{ '--i': 2 } as React.CSSProperties} className="hero-in lead mt-4 max-w-[34ch] !text-charcoal/80">{t.subtitle}</p>

          <ul style={{ '--i': 3 } as React.CSSProperties} className="hero-in mt-5 flex flex-wrap gap-2" aria-label={t.eyebrow}>
            {t.chips.map((c) => (
              <li key={c} className="rounded-full border border-navy/15 bg-white/70 px-3 py-1.5 text-[0.85rem] font-bold text-navy">
                {c}
              </li>
            ))}
          </ul>

          <div style={{ '--i': 4 } as React.CSSProperties} className="hero-in mt-6 grid grid-cols-1 gap-3 xs:grid-cols-2 sm:flex sm:flex-wrap">
            <a href={telLink(business.phoneE164)} className="btn btn-primary">
              <PhoneIcon />
              {cta.call}
            </a>
            <a
              href={waLink(business.whatsappNumber, cta.quickWhatsappText)}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-whatsapp"
            >
              <ChatIcon />
              {cta.whatsapp}
            </a>
          </div>
        </div>
      </div>

      {/* Phones: the scene gets its own block below the text.
          Tablet/desktop: the scene spans the full width at its natural 1440:600 ratio (never cropped);
          the spacer reserves the part below the horizon (≈62%) so the road and bus never sit behind text. */}
      <div className="relative mt-4 min-h-[clamp(260px,42svh,380px)] flex-1 md:static md:mt-0 md:min-h-[calc(41.667vw*0.64)]">
        <div className="hero-scene absolute inset-0 md:inset-auto md:bottom-0 md:left-0 md:right-0 md:h-[41.667vw]">
          <HighwayScene label={t.sceneLabel} />
        </div>
        <a
          href="#india"
          className="absolute bottom-4 left-1/2 z-[2] hidden -translate-x-1/2 min-h-[44px] items-center gap-2 rounded-full bg-white/85 px-4 py-2 text-sm font-bold text-navy shadow-card md:flex"
        >
          {t.scrollHint} <span aria-hidden="true">↓</span>
        </a>
      </div>
    </section>
  );
}
