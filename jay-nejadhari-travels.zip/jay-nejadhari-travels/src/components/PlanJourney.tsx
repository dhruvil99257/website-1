import type { Dictionary, Locale } from '@/i18n/types';
import { fmt, htmlLang } from '@/i18n';
import { activeFleet, seatLabel } from '@/config/fleet';
import { serviceIds } from '@/config/services';
import { business } from '@/config/business';
import InquiryForm from './InquiryForm';

export default function PlanJourney({ t, lang }: { t: Dictionary; lang: Locale }) {
  const seatingOptions = activeFleet.map((v) => ({
    id: v.id,
    label: `${t.fleet.items[v.id]?.name ?? v.id} — ${fmt(t.fleet.seats, { n: seatLabel(v) })}`,
  }));
  const tripTypes = serviceIds.map((id) => ({ id, label: t.services.items[id].title }));

  return (
    <section id="plan" aria-labelledby="plan-title" className="section-y relative bg-[linear-gradient(180deg,#F7F5EF_0%,#FCE9CC_100%)]">
      <div className="container-x relative z-[2]">
        <div className="mx-auto max-w-[860px]">
          <div className="max-w-[640px]" data-reveal>
            <p className="eyebrow">{t.form.eyebrow}</p>
            <h2 id="plan-title" className="h2 mt-3">
              {t.form.title}
            </h2>
            <p className="lead mt-4">{t.form.text}</p>
          </div>
          <div className="mt-8" data-reveal>
            <InquiryForm
              t={t.form}
              lang={lang}
              bcp47={htmlLang[lang]}
              seatingOptions={seatingOptions}
              tripTypes={tripTypes}
              business={{
                name: business.name,
                whatsappNumber: business.whatsappNumber,
                phoneE164: business.phoneE164,
                phoneDisplay: business.phoneDisplay,
              }}
            />
          </div>
        </div>
      </div>
    </section>
  );
}
