'use client';

import { useEffect, useRef, useState, type ChangeEvent, type FormEvent, type ReactElement } from 'react';
import type { Dictionary } from '@/i18n/types';
import { emptyInquiry, todayISO, validateInquiry, type FieldError, type Inquiry } from '@/lib/validation';
import { buildInquiryMessage, formatTravelDate, telLink, waLink } from '@/lib/whatsapp';
import { PREFILL_EVENT, type PrefillDetail } from '@/lib/prefill';
import { AlertIcon, ChatIcon, CheckIcon, PhoneIcon } from './Icons';

interface Option {
  id: string;
  label: string;
}

interface Props {
  t: Dictionary['form'];
  lang: string;
  bcp47: string;
  seatingOptions: Option[];
  tripTypes: Option[];
  business: { name: string; whatsappNumber: string; phoneE164: string; phoneDisplay: string };
}

type Field = keyof Inquiry;

export default function InquiryForm({ t, lang, bcp47, seatingOptions, tripTypes, business }: Props) {
  const [values, setValues] = useState<Inquiry>(emptyInquiry);
  const [errors, setErrors] = useState<FieldError[]>([]);
  const [status, setStatus] = useState<'idle' | 'opening' | 'sent'>('idle');
  const [sentUrl, setSentUrl] = useState('');
  const [minDate, setMinDate] = useState<string | undefined>(undefined);
  const formRef = useRef<HTMLFormElement>(null);

  // min date is set on the client to avoid a server/client mismatch around midnight
  useEffect(() => setMinDate(todayISO()), []);

  // "Enquire" buttons elsewhere pre-fill the form
  useEffect(() => {
    const onPrefill = (e: Event) => {
      const d = (e as CustomEvent<PrefillDetail>).detail;
      setValues((v) => ({
        ...v,
        ...(d.seating ? { seating: d.seating } : {}),
        ...(d.destination ? { destination: d.destination } : {}),
        ...(d.tripType ? { tripType: d.tripType } : {}),
      }));
      setStatus('idle');
    };
    window.addEventListener(PREFILL_EVENT, onPrefill);
    return () => window.removeEventListener(PREFILL_EVENT, onPrefill);
  }, []);

  const errorFor = (f: Field) => errors.find((e) => e.field === f);
  const msgFor = (f: Field) => {
    const e = errorFor(f);
    return e ? t.errors[e.code] : '';
  };

  const onChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const name = e.target.name as Field;
    setValues((v) => ({ ...v, [name]: e.target.value }));
    if (errorFor(name)) setErrors((errs) => errs.filter((x) => x.field !== name));
  };

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    const found = validateInquiry(values);
    setErrors(found);
    if (found.length) {
      const first = formRef.current?.querySelector<HTMLElement>(`[name="${found[0].field}"]`);
      first?.focus();
      return;
    }
    setStatus('opening');
    const seatingLabel = seatingOptions.find((o) => o.id === values.seating)?.label ?? t.seatingAny;
    const tripLabel = tripTypes.find((o) => o.id === values.tripType)?.label ?? values.tripType;
    const message = buildInquiryMessage(
      business.name,
      t.msg,
      {
        name: values.name,
        phone: values.phone,
        pickup: values.pickup,
        destination: values.destination,
        date: formatTravelDate(values.date, bcp47),
        passengers: values.passengers,
        seating: seatingLabel,
        tripType: tripLabel,
        notes: values.notes,
      },
      lang,
    );
    const url = waLink(business.whatsappNumber, message);
    setSentUrl(url);
    // Note: passing 'noopener' to window.open makes it return null, so detach the opener manually.
    const win = window.open(url, '_blank');
    if (win) {
      win.opener = null;
    } else {
      // Pop-up blocked (some in-app browsers): open in the same tab instead
      window.location.href = url;
    }
    window.setTimeout(() => setStatus('sent'), 400);
  };

  const field = (name: Field, label: string, input: ReactElement, optional = false) => {
    const err = msgFor(name);
    return (
      <div>
        <label htmlFor={`f-${name}`} className="field-label">
          {label}
          {optional && <span className="ml-1 font-normal text-muted">({t.optional})</span>}
        </label>
        {input}
        {err && (
          <p id={`f-${name}-err`} className="mt-1.5 flex items-center gap-1.5 text-[0.9rem] font-bold text-error">
            <AlertIcon size={16} /> {err}
          </p>
        )}
      </div>
    );
  };

  const common = (name: Field) => ({
    id: `f-${name}`,
    name,
    value: values[name],
    onChange,
    'aria-invalid': errorFor(name) ? true : undefined,
    'aria-describedby': errorFor(name) ? `f-${name}-err` : undefined,
    className: 'field',
  });

  return (
    <form ref={formRef} onSubmit={onSubmit} noValidate className="card relative p-5 sm:p-7 md:p-8" data-road-end>
      {errors.length > 0 && (
        <p role="alert" className="mb-5 flex items-center gap-2 rounded-sm border-l-4 border-error bg-[#FDECEA] px-4 py-3 font-bold text-error">
          <AlertIcon size={18} /> {t.errorsTitle}
        </p>
      )}
      <div className="grid gap-5 md:grid-cols-2">
        {field('name', t.name, <input {...common('name')} type="text" autoComplete="name" placeholder={t.namePh} maxLength={80} />)}
        {field(
          'phone',
          t.phone,
          <input {...common('phone')} type="tel" inputMode="tel" autoComplete="tel" placeholder={t.phonePh} maxLength={16} />,
        )}
        {field('pickup', t.pickup, <input {...common('pickup')} type="text" autoComplete="address-level2" placeholder={t.pickupPh} maxLength={120} />)}
        {field('destination', t.destination, <input {...common('destination')} type="text" placeholder={t.destinationPh} maxLength={120} />)}
        {field('date', t.date, <input {...common('date')} type="date" min={minDate} />)}
        {field(
          'passengers',
          t.passengers,
          <input {...common('passengers')} type="number" inputMode="numeric" min={1} max={500} placeholder={t.passengersPh} />,
        )}
        {field(
          'seating',
          t.seating,
          <select {...common('seating')}>
            <option value="any">{t.seatingAny}</option>
            {seatingOptions.map((o) => (
              <option key={o.id} value={o.id}>
                {o.label}
              </option>
            ))}
          </select>,
          true,
        )}
        {field(
          'tripType',
          t.tripType,
          <select {...common('tripType')}>
            <option value="" disabled>
              {t.tripTypePh}
            </option>
            {tripTypes.map((o) => (
              <option key={o.id} value={o.id}>
                {o.label}
              </option>
            ))}
          </select>,
        )}
        <div className="md:col-span-2">
          {field('notes', t.notes, <textarea {...common('notes')} rows={3} placeholder={t.notesPh} maxLength={500} />, true)}
        </div>
      </div>

      <div className="mt-6" data-submit-zone>
        {status === 'sent' && (
          <div role="status" className="mb-4 rounded-sm border-l-4 border-success bg-green-soft px-4 py-3">
            <p className="flex items-center gap-2 font-bold text-success">
              <CheckIcon size={18} /> {t.success}
            </p>
            <div className="mt-2 flex flex-wrap gap-x-5 gap-y-1">
              <a href={sentUrl} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-[44px] items-center font-bold text-navy underline underline-offset-4">
                {t.openAgain}
              </a>
              <a href={telLink(business.phoneE164)} className="inline-flex min-h-[44px] items-center gap-1.5 font-bold text-navy underline underline-offset-4">
                <PhoneIcon size={16} /> {t.callInstead}: {business.phoneDisplay}
              </a>
            </div>
          </div>
        )}
        <button type="submit" className="btn btn-whatsapp w-full text-[1.05rem] md:w-auto md:min-w-[280px]" disabled={status === 'opening'}>
          {status === 'opening' ? (
            <>
              <span className="h-5 w-5 animate-spin rounded-full border-[3px] border-white/40 border-t-white" aria-hidden="true" />
              {t.opening}
            </>
          ) : (
            <>
              <ChatIcon />
              {t.submit}
            </>
          )}
        </button>
        <p className="mt-3 text-sm text-muted">{t.privacy}</p>
      </div>
    </form>
  );
}
