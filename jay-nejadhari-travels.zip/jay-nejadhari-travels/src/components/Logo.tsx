import { business } from '@/config/business';

/**
 * Uses the supplied logo file when `business.logoSrc` is set.
 * Until then, shows the business name as plain text (no invented logo mark).
 */
export default function Logo({ onDark = false, compact = false }: { onDark?: boolean; compact?: boolean }) {
  if (business.logoSrc) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={business.logoSrc}
        alt={business.name}
        width={business.logoWidth}
        height={business.logoHeight}
        className="h-10 w-auto md:h-11"
        decoding="async"
      />
    );
  }
  return (
    <span className="flex flex-col leading-none">
      <span className={`whitespace-nowrap font-display text-[1.05rem] xs:text-[1.15rem] font-extrabold md:text-[1.3rem] ${onDark ? 'text-white' : 'text-navy'}`}>
        Jay Nejadhari
      </span>
      {!compact && (
        <span className={`mt-0.5 whitespace-nowrap text-[0.6rem] font-bold uppercase tracking-[0.12em] xs:text-[0.68rem] xs:tracking-[0.18em] ${onDark ? 'text-saffron' : 'text-saffron-deep'}`}>
          Tours and Travels
        </span>
      )}
    </span>
  );
}
