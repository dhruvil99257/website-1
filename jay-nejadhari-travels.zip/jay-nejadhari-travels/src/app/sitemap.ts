import type { MetadataRoute } from 'next';
import { siteUrl } from '@/config/business';

export const dynamic = 'force-static';

export default function sitemap(): MetadataRoute.Sitemap {
  const languages = { 'en-IN': `${siteUrl}/`, 'gu-IN': `${siteUrl}/gu/`, 'hi-IN': `${siteUrl}/hi/` };
  return ['/', '/gu/', '/hi/'].map((p) => ({
    url: siteUrl + p,
    changeFrequency: 'monthly' as const,
    priority: p === '/' ? 1 : 0.9,
    alternates: { languages },
  }));
}
