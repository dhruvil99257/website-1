import type { ReactNode } from 'react';
import RootShell from '@/components/RootShell';
import { buildMetadata } from '@/lib/seo';

export { viewport } from '@/lib/seo';
export const metadata = buildMetadata('gu');

export default function Layout({ children }: { children: ReactNode }) {
  return <RootShell lang="gu">{children}</RootShell>;
}
