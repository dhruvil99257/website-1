import en from './en';
import gu from './gu';
import hi from './hi';
import type { Dictionary, Locale } from './types';

export * from './types';

const dictionaries: Record<Locale, Dictionary> = { en, gu, hi };

export function getDictionary(lang: Locale): Dictionary {
  return dictionaries[lang];
}

/** Replace {placeholders} in a translated string. */
export function fmt(template: string, values: Record<string, string | number>): string {
  return template.replace(/\{(\w+)\}/g, (_, k) => (k in values ? String(values[k]) : `{${k}}`));
}

/** BCP-47 tags for <html lang> and date formatting. */
export const htmlLang: Record<Locale, string> = { en: 'en-IN', gu: 'gu-IN', hi: 'hi-IN' };
