import type { ServiceId } from '@/config/services';
import type { DestinationId } from '@/config/destinations';

export const locales = ['en', 'gu', 'hi'] as const;
export type Locale = (typeof locales)[number];

/** Path for each language's home page (static export, trailingSlash). */
export const localePath: Record<Locale, string> = { en: '/', gu: '/gu/', hi: '/hi/' };

/**
 * Every language file must provide every key — a missing key is a TypeScript error.
 * Strings may contain {placeholders}; use `fmt()` from i18n/index.ts.
 */
export interface Dictionary {
  langName: string;
  meta: { title: string; description: string; keywords: string };
  nav: {
    skip: string;
    home: string;
    india: string;
    fleet: string;
    services: string;
    destinations: string;
    why: string;
    reviews: string;
    plan: string;
    contact: string;
    menu: string;
    closeMenu: string;
    language: string;
    mainNav: string;
  };
  cta: {
    call: string;
    whatsapp: string;
    callShort: string;
    whatsappShort: string;
    enquire: string;
    viewDetails: string;
    planTrip: string;
    quickWhatsappText: string;
  };
  hero: {
    eyebrow: string;
    title: string;
    subtitle: string;
    chips: [string, string, string];
    sceneLabel: string;
    scrollHint: string;
  };
  india: {
    eyebrow: string;
    title: string;
    text: string;
    coverageTitle: string;
    coverageText: string;
    fromSurat: string;
    tapHint: string;
    mapLabel: string;
  };
  fleet: {
    eyebrow: string;
    title: string;
    text: string;
    seats: string; // "{n} seats"
    illustrative: string;
    idealFor: string;
    features: string;
    close: string;
    note: string;
    items: Record<string, { name: string; desc: string; idealFor: string; features: string[] }>;
  };
  services: {
    eyebrow: string;
    title: string;
    text: string;
    ask: string;
    items: Record<ServiceId, { title: string; desc: string }>;
  };
  destinations: {
    eyebrow: string;
    title: string;
    text: string;
    swipeHint: string;
    planHere: string;
    prev: string;
    next: string;
    items: Record<DestinationId, { name: string; tagline: string; places: string }>;
  };
  why: {
    eyebrow: string;
    title: string;
    text: string;
    items: [WhyItem, WhyItem, WhyItem, WhyItem];
  };
  reviews: {
    eyebrow: string;
    title: string;
    emptyTitle: string;
    emptyText: string;
    shareCta: string;
    shareText: string;
    via: string;
  };
  form: {
    eyebrow: string;
    title: string;
    text: string;
    name: string;
    namePh: string;
    phone: string;
    phonePh: string;
    pickup: string;
    pickupPh: string;
    destination: string;
    destinationPh: string;
    date: string;
    passengers: string;
    passengersPh: string;
    seating: string;
    seatingAny: string;
    tripType: string;
    tripTypePh: string;
    notes: string;
    notesPh: string;
    optional: string;
    submit: string;
    opening: string;
    privacy: string;
    success: string;
    openAgain: string;
    callInstead: string;
    errorsTitle: string;
    errors: {
      required: string;
      invalidPhone: string;
      pastDate: string;
      passengersRange: string;
      tooLong: string;
      tooShort: string;
    };
    msg: {
      heading: string;
      name: string;
      phone: string;
      pickup: string;
      destination: string;
      date: string;
      passengers: string;
      seating: string;
      tripType: string;
      notes: string;
      footer: string;
    };
  };
  footer: {
    tagline: string;
    explore: string;
    servicesTitle: string;
    contactTitle: string;
    location: string;
    follow: string;
    languageTitle: string;
    rights: string;
    credits: string;
    backToTop: string;
  };
}

interface WhyItem {
  title: string;
  text: string;
}
