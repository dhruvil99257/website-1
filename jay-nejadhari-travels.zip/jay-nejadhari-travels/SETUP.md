# SETUP — run the website on your computer

> Reads ARCHITECTURE.md and the real `package.json`. Every command below exists in this project.

## 1. Prerequisites
| Tool | Version | Check |
|---|---|---|
| Node.js | **22.6 or newer** (LTS 22 recommended) | `node -v` |
| npm | 10+ (comes with Node) | `npm -v` |
| Git | any (optional) | `git --version` |
No database is needed.

Install Node from https://nodejs.org (Windows/Mac installer) or on Linux: `curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - && sudo apt-get install -y nodejs`.

## 2. Get the code and install
```bash
# from the unzipped folder (or after git clone)
cd jay-nejadhari-travels
npm install
```

## 3. Environment file
Mac / Linux:
```bash
cp .env.example .env.local
```
Windows (Command Prompt):
```bat
copy .env.example .env.local
```
Windows (PowerShell):
```powershell
Copy-Item .env.example .env.local
```
Then open `.env.local` and set `NEXT_PUBLIC_SITE_URL` to your real domain (keep `https://www.example.com` while testing).

## 4. Database
Not used in v1 (see DATABASE.md). Content lives in `src/config/` and `src/i18n/`.

## 5. Start the development server
```bash
npm run dev
```
Open **http://localhost:3000** (English), **http://localhost:3000/gu/** (Gujarati), **http://localhost:3000/hi/** (Hindi).

To test on your phone over Wi-Fi: `npx next dev -H 0.0.0.0`, then open `http://<your-computer-IP>:3000` on the phone.

## 6. Production build & preview
```bash
npm run build      # creates the out/ folder
npm start          # serves out/ at http://localhost:3000
```
Deploy by uploading the contents of `out/` to any static host (Vercel, Netlify, Cloudflare Pages, Hostinger, cPanel `public_html`).

## 7. Run tests
```bash
npm run typecheck
npm test
```
Browser tests (optional): see TESTING.md.

## 8. Common setup errors and fixes
| # | Error | Fix |
|---|---|---|
| 1 | `'next' is not recognized` / `next: command not found` | You skipped `npm install`. Run it in the project folder. |
| 2 | `npm test` fails with `Unknown file extension ".ts"` | Node is older than 22.6. Upgrade Node (`node -v`). |
| 3 | `Port 3000 is in use` | Close the other app, or run `npx next dev -p 3001`. |
| 4 | `EACCES` / permission errors on Mac/Linux during install | Don't use `sudo npm install`; fix npm permissions or use nvm (https://github.com/nvm-sh/nvm). |
| 5 | Windows: `running scripts is disabled on this system` (PowerShell) | Use Command Prompt, or run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`. |
| 6 | Changes to `.env.local` not showing | Stop the server (Ctrl+C) and run `npm run dev` again — env vars load at start. |
| 7 | Gujarati/Hindi text shows in a plain font | Fonts are in `public/fonts`. If missing, run `npm run fonts`, then restart. |
| 8 | India map is blank | `public/images/india-map.svg` missing → run `npm run map`. |
| 9 | After deploying, pages 404 at `/gu` | Your host must serve `gu/index.html` for `/gu/`. Use the trailing slash links (the site already does) or enable "clean URLs". |
| 10 | WhatsApp doesn't open on desktop | wa.me opens WhatsApp Web/Desktop; log in to WhatsApp Web once. On phones it opens the app. |
| 11 | `npm start` asks to install `serve` | Answer `y` — it's a tiny static file server used only for previewing `out/`. |
