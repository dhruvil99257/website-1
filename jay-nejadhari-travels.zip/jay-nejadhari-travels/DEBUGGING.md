# DEBUGGING — systematic process for this project

## Rules
- Do **not** guess and do **not** rewrite large parts of the code.
- Check against ARCHITECTURE.md, DATABASE.md and API.md.
- Change nothing outside the bug's scope. If unsure, ask for more information.

## Prompt to use when something breaks
```
My project is broken. Help me debug it systematically. Do NOT guess and do NOT rewrite large parts of the code.
Error message / logs: [PASTE FULL ERROR HERE]
What I was doing: [STEPS] | What I expected: [EXPECTED] | What happened: [ACTUAL]
Follow this process:
1. Read the error and the relevant files, and explain in plain language what is going wrong
2. List the 3 most likely root causes, ranked by probability
3. Tell me how to confirm the top cause (log, test or check) before changing anything
4. Propose the smallest possible fix and show only the changed lines
5. Explain why it broke and how to prevent it next time
Rules: Check against ARCHITECTURE.md, DATABASE.md and API.md. Do not change anything outside the bug's scope.
If you are not sure, ask me for more information instead of guessing.
```

## Where to look first
| Symptom | Likely file |
|---|---|
| Wrong phone/WhatsApp number | `src/config/business.ts` |
| Text missing or wrong in one language | `src/i18n/<lang>.ts` (run `npm run typecheck`) |
| WhatsApp message format | `src/lib/whatsapp.ts` (+ `npm test`) |
| Form rejects valid input | `src/lib/validation.ts` (+ `npm test`) |
| Animation glitch / content invisible | `src/components/AnimationProvider.tsx`, `.js [data-reveal]` rules in `globals.css` |
| Road in wrong place | `src/components/SignatureRoad.tsx` (`buildGeometry`) |
| Map pins misplaced | `src/lib/geo.ts`, lat/lon in `config/destinations.ts` |
| Fonts wrong | `src/app/fonts.css` (regenerate with `npm run fonts`) |
| Header overlaps section after a link | `scroll-padding-top` in `globals.css` |

## Known issues already solved (and how to prevent them)
| # | Problem | Root cause | Fix | Prevention |
|---|---|---|---|---|
| 1 | Anchor links stopped 144 px below the header instead of 72 px | `scroll-padding-top` on `html` **and** `scroll-margin-top` on sections were both applied | Removed `scroll-margin-top` | Use only one offset mechanism |
| 2 | Every page downloaded Gujarati + Devanagari + Latin fonts (≈ 344 KB) | Fontsource per-subset CSS files have no `unicode-range` | Self-host subsets with generated `unicode-range` (`scripts/build-fonts.mjs`) | Check the Network tab → Font after font changes |
| 3 | English page downloaded a Devanagari font for one word | Language names (हिन्दी) used the web font | `.native-name` uses the device font | Keep other-script words on system fonts |
| 4 | Slow LCP (7 s) on mobile | Hero headline started at `opacity: 0` until JavaScript ran | CSS-only entrance; headline only slides | Never hide the LCP element behind JS |
| 5 | HTML 386 KB | India map paths embedded twice (HTML + hydration data) | Outline moved to `/images/india-map.svg` | Pass big static SVG as files, not client props |
| 6 | `window.open` always "blocked" | `'noopener'` feature makes `window.open` return `null` | Open without it, then set `win.opener = null` | Read MDN notes for window features |
| 7 | WhatsApp button failed contrast (3.1:1) | Bright WhatsApp green with white text | Token `whatsapp` → `#15803D` (5.0:1) | Run Lighthouse accessibility after colour changes |
| 8 | Sun clipped on wide screens | Hero scene cropped with `slice` in a short box | Scene uses its natural 1440:600 ratio on tablet/desktop | Test 1280×650 and 1920×1080 |

## Useful checks
```bash
npm run typecheck     # catches missing translation keys and type errors
npm test              # message + validation logic
npm run build         # catches server/client component mistakes
```
In the browser: DevTools → Console (errors), Network → Font/Img (what loads), Rendering → "Emulate prefers-reduced-motion", Device toolbar at 320/360/375/390/414/430 px.
