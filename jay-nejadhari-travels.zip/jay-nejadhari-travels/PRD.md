# PRD — Jay Nejadhari Tours and Travels Website

> Source of truth #1. Every other doc and every line of code follows this file.

## 1. Problem statement
Jay Nejadhari Tours and Travels (Surat, Gujarat) runs its own fleet of 4 to 56 seater vehicles and offers All India travel. Today customers can only find the business by word of mouth and must phone to learn what is available. The business needs a mobile-first website that explains the offer in seconds and turns visitors into Call / WhatsApp enquiries in English, Gujarati and Hindi.

## 2. Target users (personas)
| Persona | Who | Needs | Device |
|---|---|---|---|
| **Family planner — Hetal, 38, Surat** | Plans family trips, temple visits, weddings | Trust, right seat count, easy WhatsApp contact, Gujarati language | Mid-range Android, 4G |
| **Corporate admin — Rakesh, 45, Hazira industrial area** | Books staff transport and client pickups | Capacity range, reliability, quick quotation | Phone at work + desktop |
| **Pilgrim group leader — Ramesh, 60, nearby village** | Organises group yatras (Dwarka, Somnath, Ambaji etc.) | Big vehicles (40–56 seats), Hindi/Gujarati, one tap to call | Basic Android, slower network |

## 3. Goals
- G1. Visitor understands "travel vehicles 4–56 seats, All India, from Surat" within 5 seconds of landing.
- G2. Call and WhatsApp reachable from every scroll position in one tap.
- G3. Enquiry form produces a complete, formatted WhatsApp message to **+91 7567717570**.
- G4. Fully usable at 320–430 px; smooth native scrolling; Lighthouse mobile performance ≥ 85.
- G5. Whole site works in English, ગુજરાતી and हिन्दी, and the chosen language is remembered.

## 4. Non-goals
- No online payment, booking engine, live pricing or user accounts (pricing is per-km and negotiated).
- No backend / database in v1 — WhatsApp is the enquiry channel.
- No invented facts: no fake reviews, ratings, statistics, addresses, vehicle models or photos claimed as the real fleet.

## 5. Features
### MVP (must-have)
1. Sticky header with logo slot, section navigation, language selector, mobile drawer menu.
2. **Hero** — headline "Your Journey, Our Responsibility.", subtitle, illustrated Indian highway with animated road, Call Now + WhatsApp Inquiry buttons, entrance animation.
3. **Discover India** — illustrated SVG India map, animated routes from Surat, destination highlights, "All India coverage".
4. **Our Fleet** — editable catalogue of vehicle categories (4 → 56 seats), representative illustrations (labelled as illustrative), seat capacity, short description, View Details (modal) and Enquire (pre-fills form) actions; tilt + zoom + reveal.
5. **Our Services** — 7 service cards with distinct illustration each.
6. **Explore Destinations** — horizontal swipe gallery (Gujarat, Rajasthan, Goa, Kashmir, Maharashtra, Kerala, Himachal, Uttarakhand).
7. **Why Choose Us** — 4 verified strengths only; no counters (no numeric data supplied).
8. **Customer Reviews** — review component driven by a config array; shows a friendly empty state + "share your experience on WhatsApp" until real reviews are added.
9. **Plan Your Journey** — enquiry form (name, phone, pickup, destination, date, passengers, seating, trip type, notes) → validated → opens WhatsApp with formatted message.
10. **Contact & Footer** — name, Surat, phone, WhatsApp, language selector, service links, social links shown only when configured.
11. Floating Call + WhatsApp action bar (mobile bottom bar, desktop floating buttons) that never hides content.
12. Signature animation: scroll-drawn road connecting sections from hero to enquiry form.
13. Trilingual: EN / GU / HI on separate static URLs (`/`, `/gu/`, `/hi/`), remembered choice.
14. SEO: titles, descriptions, hreflang, LocalBusiness JSON-LD (verified data only), sitemap, robots.
15. Accessibility + `prefers-reduced-motion` support.

### V2 (should-have)
- Real fleet photographs and real logo files replacing placeholders.
- Real customer reviews; Google Business profile link.
- Separate pages per service / destination for long-tail SEO.

### Later (nice-to-have)
- Lightweight 3D vehicle viewer (Three.js) once real models/photos exist.
- Enquiry logging (Google Sheet / CRM) alongside WhatsApp.
- Trip cost estimator (only if the owner wants to publish indicative per-km rates).

## 6. User stories
- As a **family planner**, I want to see which seat sizes are available, so that I book a vehicle that fits everyone.
- As a **family planner**, I want to read the site in Gujarati, so that I fully understand it.
- As a **corporate admin**, I want to send trip details in one message, so that I get a quotation quickly.
- As a **pilgrim group leader**, I want a big Call button, so that I can talk to the owner directly.
- As **any visitor**, I want the WhatsApp message pre-written, so that I don't have to type everything.
- As **the owner**, I want to edit phone numbers, vehicles, reviews and text in one place, so that I can update the site without a developer.

## 7. Key user flows
**Flow A — Quick call:** Land → read hero → tap *Call Now* (hero or bottom bar) → phone dialer opens with 7567717570.

**Flow B — Enquiry via form:** Land → scroll fleet → tap *Enquire* on a vehicle → page scrolls to form with seating pre-selected → fill name, phone, pickup, destination, date, passengers, trip type → *Send on WhatsApp* → validation → WhatsApp opens with a formatted message to +91 7567717570.

**Flow C — Language:** Tap language selector → choose ગુજરાતી → `/gu/` loads at the same section → choice saved; future visits to `/` offer the saved language.

**Flow D — Explore:** Swipe destination gallery → tap a destination card → "Plan a trip to X" pre-fills destination in form.

## 8. Success metrics
- WhatsApp + Call clicks per visit (tracked once analytics is added).
- Enquiry form completion rate.
- Lighthouse mobile: Performance ≥ 85, Accessibility ≥ 95, SEO ≥ 95, Best practices ≥ 95.
- CLS < 0.1, LCP < 2.5 s on 4G.

## 9. Risks, assumptions, open questions
**Risks**
- Heavy animation could hurt low-end phones → reduced-motion + simplified mode + transform/opacity only.
- Translations need native-speaker review before launch.
**Assumptions**
- WhatsApp and phone number are both **+91 7567717570** (supplied).
- No logo file was attached → the header shows the business name as plain text until the real logo is placed in `public/brand/` and set in `src/config/business.ts → logoSrc`.
- No photographs supplied → original lightweight SVG illustrations are used and labelled "illustrative".
**Open questions (owner to supply — placeholders in `src/config/business.ts`)**
1. Logo file (SVG/PNG).
2. Full office address + Google Maps link (currently "Surat, Gujarat" only).
3. Exact vehicle categories in the fleet (current catalogue is an editable starting set).
4. Social media accounts / email.
5. Website domain (for sitemap & canonical URLs).
